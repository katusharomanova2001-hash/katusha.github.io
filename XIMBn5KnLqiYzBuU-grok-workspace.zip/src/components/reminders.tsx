import { useEffect, useRef } from "react";
import { toast } from "sonner";
import { inQuiet, remindAt, todayKey } from "@/lib/model";
import { usePlanner } from "@/lib/store";

const openedAt = Date.now();

export function Reminders() {
  useEffect(() => {
    const tick = () => {
      const state = usePlanner.getState();
      const now = new Date();
      const quiet = inQuiet(now, state.settings.quietStart, state.settings.quietEnd);
      if (quiet) return;

      for (const task of state.tasks) {
        if (task.done) continue;
        const at = remindAt(task);
        if (!at) continue;
        const key = `task:${task.id}:${task.due}:${task.dueTime ?? ""}:${task.remind}`;
        if (now.getTime() < at.getTime() || now.getTime() > at.getTime() + 12 * 60 * 60 * 1000) continue;
        if (!state.markFired(key)) continue;
        ping("Срок задачи", task.title);
      }

      for (const session of state.scheduled) {
        if (session.done) continue;
        const start = new Date(session.start).getTime();
        if (Number.isNaN(start)) continue;
        const at = start - session.remindMinutes * 60_000;
        const until = start + session.minutes * 60_000 + 15 * 60_000;
        if (now.getTime() < at || now.getTime() > until) continue;
        const key = `focus:${session.id}`;
        if (!usePlanner.getState().markFired(key)) continue;
        ping("Пора фокусироваться", `${session.title}, ${session.minutes} мин`);
      }

      const settings = usePlanner.getState().settings;
      if (!settings.waterOn) return;
      if (now.getTime() - openedAt < settings.waterEveryMin * 60_000) return;
      const day = todayKey(now);
      const drunk = usePlanner.getState().water[day] ?? 0;
      if (drunk >= settings.waterGoal) return;
      const slot = Math.floor((now.getHours() * 60 + now.getMinutes()) / settings.waterEveryMin);
      const key = `water:${day}:${slot}`;
      if (!usePlanner.getState().markFired(key)) return;
      ping("Вода", `Стакан воды. Сегодня ${drunk} из ${settings.waterGoal}.`);
    };

    const first = window.setTimeout(tick, 1500);
    const id = window.setInterval(tick, 30_000);
    return () => {
      window.clearTimeout(first);
      window.clearInterval(id);
    };
  }, []);

  return null;
}

function ping(title: string, body: string) {
  const notify = usePlanner.getState().settings.notify;
  toast(title, { description: body });
  if (notify && "Notification" in window && Notification.permission === "granted") {
    new Notification(title, { body });
  }
}

export function useHydratePlanner() {
  const started = useRef(false);
  useEffect(() => {
    if (started.current) return;
    started.current = true;
    void usePlanner.persist.rehydrate();
  }, []);
}
