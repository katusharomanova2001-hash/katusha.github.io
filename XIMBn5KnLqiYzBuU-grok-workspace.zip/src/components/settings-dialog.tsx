import { useRef, useState } from "react";
import { toast } from "sonner";
import { Button, Field, Label, Modal, Select } from "@/components/ui";
import { usePlanner } from "@/lib/store";

export function SettingsDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const settings = usePlanner((state) => state.settings);
  const setSettings = usePlanner((state) => state.setSettings);
  const importSnapshot = usePlanner((state) => state.importSnapshot);
  const fileRef = useRef<HTMLInputElement>(null);
  const [pending, setPending] = useState<unknown>(null);

  function exportBackup() {
    const state = usePlanner.getState();
    const payload = {
      version: 1,
      goals: state.goals,
      tasks: state.tasks,
      focusLog: state.focusLog,
      scheduled: state.scheduled,
      wishes: state.wishes,
      quotes: state.quotes,
      points: state.points,
      events: state.events,
      water: state.water,
      weekNotes: state.weekNotes,
      settings: state.settings,
      active: state.active,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "svetlitsa-backup.json";
    link.click();
    URL.revokeObjectURL(url);
    toast("Копия скачана");
  }

  return (
    <Modal open={open} title="Настройки" onClose={onClose}>
      <div className="grid gap-4">
        <div>
          <Label htmlFor="name">Как к вам обращаться</Label>
          <Field
            id="name"
            value={settings.name}
            maxLength={40}
            placeholder="Имя"
            onChange={(event) => setSettings({ name: event.target.value })}
          />
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <Label htmlFor="water-goal">Стаканов воды в день</Label>
            <Field
              id="water-goal"
              type="number"
              min={1}
              max={20}
              value={settings.waterGoal}
              onChange={(event) => setSettings({ waterGoal: clamp(Number(event.target.value), 1, 20) })}
            />
          </div>
          <div>
            <Label htmlFor="water-every">Напоминать о воде</Label>
            <Select
              id="water-every"
              value={String(settings.waterEveryMin)}
              onChange={(event) => setSettings({ waterEveryMin: Number(event.target.value) })}
            >
              <option value="45">каждые 45 минут</option>
              <option value="60">каждый час</option>
              <option value="90">каждые полтора часа</option>
              <option value="120">каждые 2 часа</option>
            </Select>
          </div>
        </div>
        <label className="flex min-h-11 items-center justify-between gap-3 text-sm">
          <span>Напоминания о воде</span>
          <input
            type="checkbox"
            className="size-5 accent-accent"
            checked={settings.waterOn}
            onChange={(event) => setSettings({ waterOn: event.target.checked })}
          />
        </label>
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <Label htmlFor="quiet-start">Тишина с</Label>
            <Field
              id="quiet-start"
              type="time"
              value={settings.quietStart}
              onChange={(event) => setSettings({ quietStart: event.target.value })}
            />
          </div>
          <div>
            <Label htmlFor="quiet-end">до</Label>
            <Field
              id="quiet-end"
              type="time"
              value={settings.quietEnd}
              onChange={(event) => setSettings({ quietEnd: event.target.value })}
            />
          </div>
        </div>
        <div className="rounded-xl bg-surface-2 p-3 text-sm text-muted">
          Напоминания о сроках, фокусе и воде приходят, пока Светлица открыта. Если вкладка закрыта, браузер
          не даст будильнику сработать. Уведомления поверх других окон можно разрешить отдельно.
        </div>
        <Button
          variant="quiet"
          onClick={async () => {
            if (!("Notification" in window)) {
              toast("Этот браузер не показывает уведомления");
              return;
            }
            const result = await Notification.requestPermission();
            setSettings({ notify: result === "granted" });
            toast(result === "granted" ? "Уведомления включены" : "Уведомления не разрешены");
          }}
        >
          {settings.notify ? "Уведомления браузера включены" : "Разрешить уведомления браузера"}
        </Button>
        <div className="rounded-xl border border-line p-3 text-sm text-muted">
          Записи живут только в этом браузере. Общий аккаунт не нужен, отдельного срока у страницы нет. Если
          очистить данные сайта или открыть другой браузер, списки пропадут — скачайте копию.
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="quiet" onClick={exportBackup}>
            Скачать копию
          </Button>
          <Button variant="ghost" onClick={() => fileRef.current?.click()}>
            Выбрать файл копии
          </Button>
          {pending ? (
            <Button
              onClick={() => {
                const ok = importSnapshot(pending);
                setPending(null);
                toast(ok ? "Копия восстановлена" : "Этот файл не похож на копию Светлицы");
              }}
            >
              Заменить текущие записи
            </Button>
          ) : null}
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            className="hidden"
            onChange={async (event) => {
              const file = event.target.files?.[0];
              event.target.value = "";
              if (!file) return;
              try {
                setPending(JSON.parse(await file.text()) as unknown);
                toast("Файл прочитан. Нажмите «Заменить текущие записи», если это нужная копия.");
              } catch {
                toast("Не удалось прочитать файл");
              }
            }}
          />
        </div>
      </div>
    </Modal>
  );
}

function clamp(value: number, min: number, max: number) {
  if (Number.isNaN(value)) return min;
  return Math.max(min, Math.min(max, value));
}
