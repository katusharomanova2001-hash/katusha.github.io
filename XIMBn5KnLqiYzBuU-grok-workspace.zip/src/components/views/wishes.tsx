import { useState } from "react";
import { toast } from "sonner";
import { Button, Card, Empty, Field, Label, PageHead, Area } from "@/components/ui";
import { usePlanner } from "@/lib/store";

export function WishesView() {
  const wishes = usePlanner((state) => state.wishes);
  const addWish = usePlanner((state) => state.addWish);
  const updateWish = usePlanner((state) => state.updateWish);
  const deleteWish = usePlanner((state) => state.deleteWish);
  const [show, setShow] = useState<"open" | "bought">("open");
  const [title, setTitle] = useState("");
  const [url, setUrl] = useState("");
  const [price, setPrice] = useState("");
  const [note, setNote] = useState("");
  const [image, setImage] = useState<string | undefined>();
  const visible = wishes.filter((wish) => (show === "bought" ? wish.bought : !wish.bought));

  return (
    <div>
      <PageHead kicker="Не срочно, но хочется" title="Желания" />
      <Card>
        <form
          className="grid gap-3"
          onSubmit={(event) => {
            event.preventDefault();
            if (!title.trim()) return;
            addWish({ title, url, price, note, image });
            setTitle("");
            setUrl("");
            setPrice("");
            setNote("");
            setImage(undefined);
            toast("Добавлено в список");
          }}
        >
          <div>
            <Label htmlFor="wish-title">Что хочется</Label>
            <Field id="wish-title" value={title} onChange={(event) => setTitle(event.target.value)} />
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <Label htmlFor="wish-url">Ссылка</Label>
              <Field id="wish-url" type="url" placeholder="https://" value={url} onChange={(event) => setUrl(event.target.value)} />
            </div>
            <div>
              <Label htmlFor="wish-price">Цена, как вам удобно</Label>
              <Field id="wish-price" value={price} onChange={(event) => setPrice(event.target.value)} placeholder="4 200 ₽" />
            </div>
          </div>
          <div>
            <Label htmlFor="wish-note">Заметка</Label>
            <Area id="wish-note" value={note} onChange={(event) => setNote(event.target.value)} />
          </div>
          <div>
            <Label htmlFor="wish-photo">Фото</Label>
            <Field
              id="wish-photo"
              type="file"
              accept="image/*"
              onChange={async (event) => {
                const file = event.target.files?.[0];
                event.target.value = "";
                if (!file) return;
                try {
                  const data = await compressImage(file);
                  if (data.length > 180_000) {
                    toast("Фото слишком большое. Возьмите другое или поменьше.");
                    return;
                  }
                  setImage(data);
                } catch {
                  toast("Не удалось прочитать фото");
                }
              }}
            />
            {image ? <img src={image} alt="" className="mt-3 h-36 w-full rounded-xl object-cover" /> : null}
          </div>
          <Button type="submit">Добавить</Button>
          <p className="text-sm text-muted">Фото остаётся в этом браузере вместе с остальными записями.</p>
        </form>
      </Card>
      <div className="mt-5 flex gap-2">
        <button type="button" className={chip(show === "open")} onClick={() => setShow("open")}>
          Хочу
        </button>
        <button type="button" className={chip(show === "bought")} onClick={() => setShow("bought")}>
          Уже есть
        </button>
      </div>
      {visible.length === 0 ? (
        <div className="mt-5">
          <Empty title="Список пуст" text="Сюда можно складывать вещи, курсы и поездки: название, ссылку и фото." />
        </div>
      ) : (
        <ul className="mt-5 grid gap-4 sm:grid-cols-2">
          {visible.map((wish) => (
            <li key={wish.id}>
              <Card className="flex h-full flex-col">
                {wish.image ? (
                  <img src={wish.image} alt="" className="mb-4 h-44 w-full rounded-xl object-cover" />
                ) : (
                  <div className="mb-4 flex h-44 items-center justify-center rounded-xl bg-accent-soft">
                    <span className="font-display text-5xl text-accent">{wish.title.slice(0, 1)}</span>
                  </div>
                )}
                <h2 className={wish.bought ? "font-display text-3xl text-muted line-through" : "font-display text-3xl"}>{wish.title}</h2>
                {wish.price ? <p className="mt-1 text-sm text-muted">{wish.price}</p> : null}
                {wish.note ? <p className="mt-2 text-sm">{wish.note}</p> : null}
                <div className="mt-4 flex flex-wrap gap-2">
                  {wish.url ? (
                    <a href={wish.url} target="_blank" rel="noreferrer" className="inline-flex min-h-11 items-center text-sm font-semibold text-accent">
                      Открыть ссылку
                    </a>
                  ) : null}
                  <Button variant="quiet" onClick={() => updateWish(wish.id, { bought: !wish.bought })}>
                    {wish.bought ? "Снова хочу" : "Уже куплено"}
                  </Button>
                  <Button variant="danger" onClick={() => deleteWish(wish.id)}>
                    Удалить
                  </Button>
                </div>
              </Card>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function chip(active: boolean) {
  return active
    ? "min-h-11 rounded-xl bg-accent-soft px-4 text-sm font-semibold"
    : "min-h-11 rounded-xl px-4 text-sm text-muted";
}

function compressImage(file: File) {
  return new Promise<string>((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => {
      const max = 960;
      const scale = Math.min(1, max / Math.max(image.width, image.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(image.width * scale));
      canvas.height = Math.max(1, Math.round(image.height * scale));
      const context = canvas.getContext("2d");
      if (!context) {
        URL.revokeObjectURL(url);
        reject(new Error("canvas"));
        return;
      }
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      const data = canvas.toDataURL("image/jpeg", 0.72);
      URL.revokeObjectURL(url);
      resolve(data);
    };
    image.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("image"));
    };
    image.src = url;
  });
}
