import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { toast } from "sonner";
import { Button, Card, Field, Meter, PriorityMark } from "@/components/ui";
import {
  completionStreak,
  ENERGY_LABEL,
  greet,
  pickQuote,
  weekKey,
  type Task,
} from "@/lib/model";
import { usePlanner } from "@/lib/store";
import { useTodayKey } from "@/lib/use-today";

export function TodayView() {
  const day = useTodayKey();
  const settings = usePlanner((state) => state.settings);
  const setSettings = usePlanner((state) => state.setSettings);
  const quotes = usePlanner((state) => state.quotes);
  const points = usePlanner((state) => state.points);
  const tasks = usePlanner((state) => state.tasks);
  const water = usePlanner((state) => state.water);
  const addWater = usePlanner((state) => state.addWater);
  const toggleTask = usePlanner((state) => state.toggleTask);
  const addTask = usePlanner((state) => state.addTask);
  const scheduled = usePlanner((state) => state.scheduled);
  const events = usePlanner((state) => state.events);
  const weekNotes = usePlanner((state) => state.weekNotes);
  const setWeekNote = usePlanner((state) => state.setWeekNote);
  const [hello, setHello] = useState("Здравствуйте");
  const [dateLabel, setDateLabel] = useState("Сегодня");
  const [draft, setDraft] = useState("");

  useEffect(() => {
    const now = new Date();
    setHello(greet(now));
    setDateLabel(format(now, "EEEE, d MMMM", { locale: ru }).replace(/^./, (letter) => letter.toUpperCase()));
  }, [day]);

  const quote = pickQuote(quotes, settings.activeQuoteId);
  const name = settings.name.trim();
  const glasses = day ? (water[day] ?? 0) : 0;
  const open = tasks.filter((task) => !task.done);
  const anchor = open.find((task) => task.anchor);
  const overdue = day ? open.filter((task) => task.due && task.due < day && !task.anchor) : [];
  const todayTasks = day ? open.filter((task) => task.due === day && !task.anchor) : [];
  const streak = day ? completionStreak(events, day) : 0;
  const noteKey = day ? weekKey(new Date()) : "";
  const note = weekNotes[noteKey];
  const upcoming = scheduled
    .filter((item) => !item.done)
    .slice()
    .sort((a, b) => a.start.localeCompare(b.start))[0];

  return (
    <div className="grid gap-5">
      <div>
        <p className="text-sm text-muted">{dateLabel}</p>
        <h1 className="font-display text-5xl leading-tight text-ink md:text-6xl">
          {name ? `${hello}, ${name}` : hello}
        </h1>
        {streak >= 2 ? (
          <p className="mt-2 text-sm text-muted">Уже {streak} дн. подряд закрываете хотя бы одно.</p>
        ) : null}
      </div>

      {!name ? (
        <Card>
          <label htmlFor="hello-name" className="text-sm text-muted">
            Как к вам обращаться?
          </label>
          <Field
            id="hello-name"
            className="mt-2"
            maxLength={40}
            placeholder="Имя"
            value={settings.name}
            onChange={(event) => setSettings({ name: event.target.value })}
          />
        </Card>
      ) : null}

      <div className="grid gap-5 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <blockquote className="font-display text-3xl italic leading-snug text-ink md:text-4xl">{quote.text}</blockquote>
          <p className="mt-4 text-sm text-muted">{quote.author}</p>
          <div className="mt-5 flex flex-wrap items-center gap-3">
            <p className="tabular-nums text-sm">
              <span className="font-semibold">{points}</span> <span className="text-muted">очков</span>
            </p>
            <Link to="/quotes" className="min-h-11 inline-flex items-center text-sm font-semibold text-accent">
              Витрина цитат
            </Link>
          </div>
        </Card>
        <Card className="lg:col-span-2">
          <div className="flex items-baseline justify-between gap-3">
            <h2 className="font-display text-3xl">Вода</h2>
            <p className="tabular-nums text-sm text-muted">
              {glasses} / {settings.waterGoal}
            </p>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            {Array.from({ length: settings.waterGoal }, (_, index) => {
              const filled = index < glasses;
              return (
                <button
                  key={index}
                  type="button"
                  aria-label={filled ? `Убрать стакан ${index + 1}` : `Отметить стакан ${index + 1}`}
                  disabled={!day}
                  onClick={() => {
                    if (!day) return;
                    const next = filled ? index : index + 1;
                    addWater(day, next - glasses);
                  }}
                  className={
                    filled
                      ? "size-11 rounded-full bg-accent"
                      : "size-11 rounded-full border border-line bg-surface-2"
                  }
                />
              );
            })}
          </div>
          <p className="mt-3 text-sm text-muted">Пустой кружок доливает до него. Полный откатывает.</p>
        </Card>
      </div>

      {anchor ? (
        <Card>
          <p className="text-sm text-muted">Главное на сегодня</p>
          <div className="mt-2 flex items-start gap-3">
            <input
              type="checkbox"
              className="mt-2 size-5 accent-accent"
              checked={false}
              aria-label={`Выполнено: ${anchor.title}`}
              onChange={() => reward(toggleTask(anchor.id))}
            />
            <div className="min-w-0 flex-1">
              <h2 className="font-display text-3xl leading-tight">{anchor.title}</h2>
              <p className="mt-1 text-sm text-muted">
                <PriorityMark priority={anchor.priority} />
                {anchor.energy !== "any" ? ` · ${ENERGY_LABEL[anchor.energy]}` : ""}
                {anchor.progress > 0 ? ` · ${anchor.progress}%` : ""}
              </p>
              {anchor.priority === "critical" || anchor.priority === "high" ? (
                <div className="mt-3">
                  <Meter value={anchor.progress} label="Прогресс главной задачи" />
                </div>
              ) : null}
            </div>
          </div>
          <Link to="/focus" className="mt-4 inline-flex min-h-11 items-center text-sm font-semibold text-accent">
            25 минут на это
          </Link>
        </Card>
      ) : null}

      <Card>
        <h2 className="font-display text-3xl">На сегодня</h2>
        <form
          className="mt-4 flex flex-col gap-2 sm:flex-row"
          onSubmit={(event) => {
            event.preventDefault();
            if (!draft.trim() || !day) return;
            addTask({ title: draft, due: day, priority: "high", remind: "morning" });
            setDraft("");
          }}
        >
          <Field
            value={draft}
            onChange={(event) => setDraft(event.target.value)}
            placeholder="Быстро добавить задачу на сегодня"
            aria-label="Новая задача на сегодня"
          />
          <Button type="submit">Добавить</Button>
        </form>
        <TaskGroup title="Просрочено" tasks={overdue} onToggle={(id) => reward(toggleTask(id))} />
        <TaskGroup title={anchor ? "Ещё сегодня" : "Сегодня"} tasks={todayTasks} onToggle={(id) => reward(toggleTask(id))} />
        {!anchor && overdue.length === 0 && todayTasks.length === 0 ? (
          <p className="mt-4 text-muted">
            Пока пусто. Добавьте одну задачу сюда или{" "}
            <Link to="/goals" className="font-semibold text-accent">
              соберите цель
            </Link>
            .
          </p>
        ) : null}
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <h2 className="font-display text-3xl">Ближайший фокус</h2>
          {upcoming ? (
            <p className="mt-3">
              <span className="font-semibold">{upcoming.title}</span>
              <span className="mt-1 block text-sm text-muted">
                {format(new Date(upcoming.start), "d MMMM, HH:mm", { locale: ru })} · {upcoming.minutes} мин
              </span>
            </p>
          ) : (
            <p className="mt-3 text-muted">Сессий впереди нет.</p>
          )}
          <Link to="/focus" className="mt-4 inline-flex min-h-11 items-center text-sm font-semibold text-accent">
            Открыть фокус
          </Link>
        </Card>
        <Card>
          <h2 className="font-display text-3xl">Итог недели</h2>
          <p className="mt-1 text-sm text-muted">Три короткие строки, чтобы неделя не рассыпалась.</p>
          <WeekField
            label="Что сдвинулось"
            value={note?.moved ?? ""}
            onBlur={(value) => noteKey && setWeekNote(noteKey, { moved: value })}
          />
          <WeekField
            label="Что отпустить"
            value={note?.drop ?? ""}
            onBlur={(value) => noteKey && setWeekNote(noteKey, { drop: value })}
          />
          <WeekField
            label="Чему отдать утро"
            value={note?.focus ?? ""}
            onBlur={(value) => noteKey && setWeekNote(noteKey, { focus: value })}
          />
        </Card>
      </div>
    </div>
  );
}

function reward(delta: number) {
  if (delta > 0) toast(`+${delta} очков`);
  if (delta < 0) toast("Отметку сняли, очки вернулись");
}

function TaskGroup({ title, tasks, onToggle }: { title: string; tasks: Task[]; onToggle: (id: string) => void }) {
  if (!tasks.length) return null;
  return (
    <div className="mt-4">
      <p className="text-sm text-muted">{title}</p>
      <ul className="mt-2 divide-y divide-line">
        {tasks.map((task) => (
          <li key={task.id} className="flex items-start gap-3 py-3">
            <input
              type="checkbox"
              className="mt-1 size-5 accent-accent"
              checked={false}
              aria-label={`Выполнено: ${task.title}`}
              onChange={() => onToggle(task.id)}
            />
            <div className="min-w-0">
              <p className="font-medium">{task.title}</p>
              <PriorityMark priority={task.priority} />
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function WeekField({ label, value, onBlur }: { label: string; value: string; onBlur: (value: string) => void }) {
  const [text, setText] = useState(value);
  useEffect(() => setText(value), [value]);
  return (
    <label className="mt-3 block text-sm">
      <span className="text-muted">{label}</span>
      <Field
        className="mt-1"
        value={text}
        maxLength={160}
        onChange={(event) => setText(event.target.value)}
        onBlur={() => onBlur(text)}
      />
    </label>
  );
}
