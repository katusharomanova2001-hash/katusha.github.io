import { useEffect, useState } from "react";
import { addDays, endOfMonth, format, startOfMonth, startOfWeek } from "date-fns";
import { ru } from "date-fns/locale";
import { Button, PageHead } from "@/components/ui";
import { PRIORITY_LABEL, todayKey } from "@/lib/model";
import { usePlanner } from "@/lib/store";

export function PrintView() {
  const tasks = usePlanner((state) => state.tasks);
  const goals = usePlanner((state) => state.goals);
  const [mode, setMode] = useState<"week" | "month">("week");
  const [anchor, setAnchor] = useState<Date | null>(null);

  useEffect(() => {
    setAnchor(new Date());
  }, []);

  const days = anchor ? range(mode, anchor) : [];

  return (
    <div>
      <div className="no-print">
        <PageHead kicker="Для ручки" title="Печать">
          <Button onClick={() => window.print()}>Распечатать</Button>
        </PageHead>
        <div className="mb-5 flex gap-2">
          <button type="button" className={chip(mode === "week")} onClick={() => setMode("week")}>
            Неделя
          </button>
          <button type="button" className={chip(mode === "month")} onClick={() => setMode("month")}>
            Месяц
          </button>
        </div>
        <p className="mb-5 text-sm text-muted">
          Лист соберётся по задачам со сроком. Пустые строки можно дописать от руки и зачёркивать.
        </p>
      </div>
      <article className="print-sheet rounded-2xl border border-line bg-surface p-6 text-ink shadow-card">
        <p className="font-display text-4xl">Светлица</p>
        <p className="mt-1 text-sm text-muted">
          {anchor
            ? mode === "week"
              ? `Неделя ${format(days[0] ?? anchor, "d MMMM", { locale: ru })} — ${format(days[days.length - 1] ?? anchor, "d MMMM", { locale: ru })}`
              : format(anchor, "LLLL yyyy", { locale: ru })
            : "Список"}
        </p>
        {goals.length > 0 ? (
          <ul className="mt-4 text-sm">
            {goals.slice(0, 6).map((goal) => (
              <li key={goal.id}>
                {goal.kind === "dream" ? "Мечта" : "Цель"}: {goal.title}
              </li>
            ))}
          </ul>
        ) : null}
        <div className="mt-6 grid gap-6">
          {days.map((date) => {
            const key = todayKey(date);
            const items = tasks.filter((task) => task.due === key);
            return (
              <section key={key}>
                <h2 className="font-display text-2xl">
                  {format(date, "EEEE, d MMMM", { locale: ru }).replace(/^./, (letter) => letter.toUpperCase())}
                </h2>
                <ul className="mt-2">
                  {items.map((task) => (
                    <li key={task.id} className="flex items-start gap-3 border-b border-line py-2">
                      <Box done={task.done} />
                      <div>
                        <p className={task.done ? "line-through" : ""}>{task.title}</p>
                        <p className="text-sm text-muted">
                          {PRIORITY_LABEL[task.priority]}
                          {task.notes ? ` · ${task.notes}` : ""}
                        </p>
                      </div>
                    </li>
                  ))}
                  {Array.from({ length: items.length > 0 ? 1 : 3 }, (_, index) => (
                    <li key={`blank-${index}`} className="flex items-center gap-3 border-b border-line py-3">
                      <Box done={false} />
                      <span className="block h-4 flex-1 border-b border-line" />
                    </li>
                  ))}
                </ul>
              </section>
            );
          })}
        </div>
      </article>
    </div>
  );
}

function Box({ done }: { done: boolean }) {
  return <span className={done ? "mt-1 inline-block size-4 shrink-0 border border-ink bg-ink" : "mt-1 inline-block size-4 shrink-0 border border-ink"} />;
}

function chip(active: boolean) {
  return active
    ? "min-h-11 rounded-xl bg-accent-soft px-4 text-sm font-semibold"
    : "min-h-11 rounded-xl px-4 text-sm text-muted";
}

function range(mode: "week" | "month", anchor: Date) {
  if (mode === "week") {
    const start = startOfWeek(anchor, { weekStartsOn: 1 });
    return Array.from({ length: 7 }, (_, index) => addDays(start, index));
  }
  const start = startOfMonth(anchor);
  const end = endOfMonth(anchor);
  const days: Date[] = [];
  for (let date = start; date <= end; date = addDays(date, 1)) days.push(date);
  return days;
}
