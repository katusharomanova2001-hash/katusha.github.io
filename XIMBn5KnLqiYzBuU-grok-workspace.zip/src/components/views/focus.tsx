import { useEffect, useState } from "react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { toast } from "sonner";
import { Button, Card, Field, Label, PageHead, Select } from "@/components/ui";
import { elapsedMs, weekKey } from "@/lib/model";
import { usePlanner } from "@/lib/store";
import { useTodayKey } from "@/lib/use-today";

export function FocusView() {
  const tasks = usePlanner((state) => state.tasks);
  const active = usePlanner((state) => state.active);
  const focusLog = usePlanner((state) => state.focusLog);
  const scheduled = usePlanner((state) => state.scheduled);
  const startFocus = usePlanner((state) => state.startFocus);
  const pauseFocus = usePlanner((state) => state.pauseFocus);
  const resumeFocus = usePlanner((state) => state.resumeFocus);
  const finishFocus = usePlanner((state) => state.finishFocus);
  const discardFocus = usePlanner((state) => state.discardFocus);
  const scheduleFocus = usePlanner((state) => state.scheduleFocus);
  const deleteScheduled = usePlanner((state) => state.deleteScheduled);
  const day = useTodayKey();
  const [now, setNow] = useState(() => Date.now());
  const [minutes, setMinutes] = useState(25);
  const [taskId, setTaskId] = useState("");
  const [title, setTitle] = useState("");
  const [when, setWhen] = useState("");
  const [planMinutes, setPlanMinutes] = useState(25);
  const [remind, setRemind] = useState(10);

  useEffect(() => {
    if (!active?.running) return;
    const id = window.setInterval(() => setNow(Date.now()), 250);
    return () => window.clearInterval(id);
  }, [active?.running]);

  useEffect(() => {
    if (!active?.running) return;
    const left = active.plannedMinutes * 60_000 - elapsedMs(active);
    const id = window.setTimeout(() => {
      const logged = usePlanner.getState().finishFocus();
      if (logged > 0) toast(`Сессия записана: ${logged} мин`);
    }, Math.max(0, left));
    return () => window.clearTimeout(id);
  }, [active?.running, active?.startedAt, active?.accumulatedMs, active?.plannedMinutes]);

  const spent = active ? elapsedMs(active, now) : 0;
  const total = (active?.plannedMinutes ?? minutes) * 60_000;
  const left = Math.max(0, total - spent);
  const ratio = total === 0 ? 0 : Math.min(1, spent / total);
  const radius = 52;
  const circ = 2 * Math.PI * radius;
  const clock = formatClock(left);
  const weekStart = day ? weekKey(new Date()) : "";
  const weekLog = focusLog.filter((entry) => !weekStart || entry.day >= weekStart);
  const weekMinutes = weekLog.reduce((sum, entry) => sum + entry.minutes, 0);
  const openTasks = tasks.filter((task) => !task.done);
  const anchor = openTasks.find((task) => task.anchor);

  useEffect(() => {
    if (anchor && !taskId) setTaskId(anchor.id);
  }, [anchor, taskId]);

  return (
    <div>
      <PageHead kicker="Сколько вы были здесь" title="Фокус" />
      <div className="grid gap-5 lg:grid-cols-2">
        <Card className="flex flex-col items-center">
          <div className="relative grid place-items-center">
            <svg viewBox="0 0 120 120" className="size-56 -rotate-90" aria-hidden>
              <circle cx="60" cy="60" r={radius} fill="none" strokeWidth="8" className="stroke-line" />
              <circle
                cx="60"
                cy="60"
                r={radius}
                fill="none"
                strokeWidth="8"
                strokeLinecap="round"
                className="stroke-accent"
                strokeDasharray={circ}
                strokeDashoffset={circ * (1 - ratio)}
              />
            </svg>
            <div className="absolute text-center">
              <p className="font-display text-5xl tabular-nums text-ink">{clock}</p>
              <p className="mt-1 max-w-40 text-sm text-muted">{active?.title ?? "Готово к старту"}</p>
            </div>
          </div>
          {!active ? (
            <div className="mt-6 grid w-full gap-3">
              <div className="flex flex-wrap gap-2">
                {[15, 25, 45].map((value) => (
                  <Button key={value} variant={minutes === value ? "primary" : "quiet"} onClick={() => setMinutes(value)}>
                    {value} мин
                  </Button>
                ))}
              </div>
              <Label htmlFor="focus-task">Задача</Label>
              <Select id="focus-task" value={taskId} onChange={(event) => setTaskId(event.target.value)}>
                <option value="">Без привязки</option>
                {openTasks.map((task) => (
                  <option key={task.id} value={task.id}>
                    {task.title}
                  </option>
                ))}
              </Select>
              <Button
                onClick={() => {
                  const task = openTasks.find((item) => item.id === taskId);
                  const ok = startFocus({
                    title: task?.title || "Свободный фокус",
                    taskId: task?.id,
                    plannedMinutes: minutes,
                  });
                  if (!ok) toast("Сначала завершите текущую сессию");
                }}
              >
                Начать
              </Button>
            </div>
          ) : (
            <div className="mt-6 flex flex-wrap justify-center gap-2">
              {active.running ? (
                <Button variant="quiet" onClick={pauseFocus}>
                  Пауза
                </Button>
              ) : (
                <Button variant="quiet" onClick={resumeFocus}>
                  Дальше
                </Button>
              )}
              <Button
                onClick={() => {
                  const logged = finishFocus();
                  toast(logged > 0 ? `Записано ${logged} мин` : "Слишком коротко, в отчёт не попало");
                }}
              >
                Завершить
              </Button>
              <Button variant="ghost" onClick={discardFocus}>
                Сбросить
              </Button>
            </div>
          )}
        </Card>

        <div className="grid gap-5">
          <Card>
            <h2 className="font-display text-3xl">Эта неделя</h2>
            <p className="mt-2 font-display text-5xl tabular-nums">{weekMinutes}</p>
            <p className="text-sm text-muted">минут в фокусе</p>
            <ul className="mt-4 divide-y divide-line">
              {weekLog.slice(0, 6).map((entry) => (
                <li key={entry.id} className="flex items-baseline justify-between gap-3 py-2 text-sm">
                  <span className="min-w-0 truncate">{entry.title}</span>
                  <span className="tabular-nums text-muted">{entry.minutes} мин</span>
                </li>
              ))}
              {weekLog.length === 0 ? <li className="py-2 text-sm text-muted">Сессий ещё не было.</li> : null}
            </ul>
          </Card>
          <Card>
            <h2 className="font-display text-3xl">Запланировать</h2>
            <form
              className="mt-4 grid gap-3"
              onSubmit={(event) => {
                event.preventDefault();
                const task = openTasks.find((item) => item.id === taskId);
                scheduleFocus({
                  title: title.trim() || task?.title || "Фокус",
                  taskId: task?.id,
                  start: new Date(when).toISOString(),
                  minutes: planMinutes,
                  remindMinutes: remind,
                });
                setTitle("");
                setWhen("");
                toast("Сессия в календаре. Напомню, пока страница открыта.");
              }}
            >
              <Field value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Название, если не из задачи" aria-label="Название сессии" />
              <Field type="datetime-local" required value={when} aria-label="Когда" onChange={(event) => setWhen(event.target.value)} />
              <div className="grid grid-cols-2 gap-3">
                <Field
                  type="number"
                  min={5}
                  max={180}
                  value={planMinutes}
                  aria-label="Длительность"
                  onChange={(event) => setPlanMinutes(Number(event.target.value))}
                />
                <Select value={String(remind)} aria-label="Напомнить за" onChange={(event) => setRemind(Number(event.target.value))}>
                  <option value="0">В момент старта</option>
                  <option value="5">За 5 минут</option>
                  <option value="10">За 10 минут</option>
                  <option value="15">За 15 минут</option>
                  <option value="30">За 30 минут</option>
                </Select>
              </div>
              <Button type="submit">Поставить в календарь</Button>
            </form>
          </Card>
        </div>
      </div>
      <ul className="mt-5 grid gap-3">
        {scheduled
          .filter((item) => !item.done)
          .slice()
          .sort((a, b) => a.start.localeCompare(b.start))
          .map((item) => (
            <li key={item.id}>
              <Card className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-medium">{item.title}</p>
                  <p className="text-sm text-muted">
                    {format(new Date(item.start), "d MMMM, HH:mm", { locale: ru })} · {item.minutes} мин · напоминание за{" "}
                    {item.remindMinutes} мин
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="quiet"
                    onClick={() => {
                      const ok = startFocus({
                        title: item.title,
                        taskId: item.taskId,
                        plannedMinutes: item.minutes,
                        scheduleId: item.id,
                      });
                      if (!ok) toast("Сначала завершите текущую сессию");
                    }}
                  >
                    Начать сейчас
                  </Button>
                  <Button variant="ghost" onClick={() => deleteScheduled(item.id)}>
                    Убрать
                  </Button>
                </div>
              </Card>
            </li>
          ))}
      </ul>
    </div>
  );
}

function formatClock(ms: number) {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
