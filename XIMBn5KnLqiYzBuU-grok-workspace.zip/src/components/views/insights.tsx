import { useMemo } from "react";
import { format, parseISO } from "date-fns";
import { ru } from "date-fns/locale";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Card, PageHead } from "@/components/ui";
import { focusMinutes, todayKey, type EventType } from "@/lib/model";
import { usePlanner } from "@/lib/store";
import { useTodayKey } from "@/lib/use-today";

const LABELS: Record<EventType, string> = {
  goal_created: "Цель",
  task_created: "Задача",
  focus_started: "Фокус",
  task_completed: "Готово",
};

export function InsightsView() {
  const events = usePlanner((state) => state.events);
  const focusLog = usePlanner((state) => state.focusLog);
  const day = useTodayKey();

  const chart = useMemo(() => {
    if (!day) return [];
    const start = parseDay(day);
    start.setDate(start.getDate() - 13);
    return Array.from({ length: 14 }, (_, index) => {
      const date = new Date(start);
      date.setDate(start.getDate() + index);
      const key = todayKey(date);
      const same = events.filter((event) => event.day === key);
      return {
        name: format(date, "d MMM", { locale: ru }),
        goals: same.filter((event) => event.type === "goal_created").length,
        tasks: same.filter((event) => event.type === "task_created").length,
        focus: same.filter((event) => event.type === "focus_started").length,
        done: same.filter((event) => event.type === "task_completed").length,
      };
    });
  }, [day, events]);

  const totals = {
    goals: events.filter((event) => event.type === "goal_created").length,
    tasks: events.filter((event) => event.type === "task_created").length,
    focus: events.filter((event) => event.type === "focus_started").length,
    done: events.filter((event) => event.type === "task_completed").length,
  };
  const byTask = new Map<string, number>();
  for (const entry of focusLog) {
    byTask.set(entry.title, (byTask.get(entry.title) ?? 0) + entry.minutes);
  }
  const top = [...byTask.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5);

  return (
    <div>
      <PageHead kicker="Что уже произошло" title="Обзор" />
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Целей создано" value={totals.goals} />
        <Stat label="Задач создано" value={totals.tasks} />
        <Stat label="Фокус-сессий" value={totals.focus} />
        <Stat label="Задач закрыто" value={totals.done} />
      </div>
      <Card className="mt-5">
        <h2 className="font-display text-3xl">14 дней</h2>
        <p className="mt-1 text-sm text-muted">Создание целей и задач, старты фокуса и закрытые задачи.</p>
        <div className="mt-4 h-64 w-full min-w-0">
          {chart.length === 0 ? (
            <p className="text-muted">Считаю дни.</p>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chart}>
                <CartesianGrid vertical={false} stroke="var(--color-line)" />
                <XAxis dataKey="name" tick={{ fill: "var(--color-muted)", fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis allowDecimals={false} width={28} tick={{ fill: "var(--color-muted)", fontSize: 12 }} axisLine={false} tickLine={false} />
                <Tooltip
                  cursor={{ fill: "var(--color-surface-2)" }}
                  contentStyle={{
                    background: "var(--color-surface)",
                    border: "1px solid var(--color-line)",
                    borderRadius: 12,
                    color: "var(--color-ink)",
                  }}
                />
                <Bar dataKey="done" name="Закрыто" fill="var(--color-accent)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="focus" name="Фокус" fill="var(--color-ink)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="tasks" name="Задачи" fill="var(--color-muted)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="goals" name="Цели" fill="var(--color-line)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </Card>
      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <Card>
          <h2 className="font-display text-3xl">Куда ушло внимание</h2>
          <p className="mt-1 text-sm text-muted">Всего {focusMinutes(focusLog)} мин фокуса.</p>
          <ul className="mt-4 divide-y divide-line">
            {top.map(([name, minutes]) => (
              <li key={name} className="flex items-baseline justify-between gap-3 py-2 text-sm">
                <span className="min-w-0 truncate">{name}</span>
                <span className="tabular-nums text-muted">{minutes} мин</span>
              </li>
            ))}
            {top.length === 0 ? <li className="py-2 text-sm text-muted">Запустите первую сессию, и здесь появится отчёт.</li> : null}
          </ul>
        </Card>
        <Card>
          <h2 className="font-display text-3xl">Лента</h2>
          <ul className="mt-4 divide-y divide-line">
            {events.slice(0, 8).map((event) => (
              <li key={event.id} className="py-2 text-sm">
                <p>
                  <span className="text-muted">{LABELS[event.type]} · </span>
                  {event.label}
                </p>
                <p className="text-muted">{format(parseISO(event.at), "d MMMM, HH:mm", { locale: ru })}</p>
              </li>
            ))}
            {events.length === 0 ? <li className="py-2 text-sm text-muted">Пока нечего считать. Создайте цель или задачу.</li> : null}
          </ul>
        </Card>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <Card>
      <p className="text-sm text-muted">{label}</p>
      <p className="mt-2 font-display text-4xl tabular-nums">{value}</p>
    </Card>
  );
}

function parseDay(day: string) {
  const [y, m, d] = day.split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}
