import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { planGoal, type GoalPlan } from "@/lib/ai.functions";
import { Button, Card, Empty, Field, Label, Meter, Modal, PageHead, Select, Area } from "@/components/ui";
import { ENERGY_LABEL, PRIORITY_LABEL, goalProgress, type GoalKind, type Priority } from "@/lib/model";
import { usePlanner } from "@/lib/store";

const PRIORITIES = Object.keys(PRIORITY_LABEL) as Priority[];

export function GoalsView() {
  const goals = usePlanner((state) => state.goals);
  const tasks = usePlanner((state) => state.tasks);
  const addGoal = usePlanner((state) => state.addGoal);
  const addTask = usePlanner((state) => state.addTask);
  const deleteGoal = usePlanner((state) => state.deleteGoal);
  const addPlannedGoal = usePlanner((state) => state.addPlannedGoal);
  const [kind, setKind] = useState<GoalKind | "all">("all");
  const [manual, setManual] = useState(false);
  const [aiOpen, setAiOpen] = useState(false);
  const visible = goals.filter((goal) => (kind === "all" ? true : goal.kind === kind));

  return (
    <div>
      <PageHead kicker="Куда вы идёте" title="Цели и мечты">
        <div className="flex flex-wrap gap-2">
          <Button onClick={() => setAiOpen(true)}>Собрать шаги</Button>
          <Button variant="quiet" onClick={() => setManual(true)}>
            Записать вручную
          </Button>
        </div>
      </PageHead>
      <div className="mb-5 flex flex-wrap gap-2">
        {(
          [
            ["all", "Все"],
            ["goal", "Цели"],
            ["dream", "Мечты"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setKind(id)}
            className={
              kind === id
                ? "min-h-11 rounded-xl bg-accent-soft px-4 text-sm font-semibold text-ink"
                : "min-h-11 rounded-xl px-4 text-sm text-muted"
            }
          >
            {label}
          </button>
        ))}
      </div>
      {visible.length === 0 ? (
        <Empty
          title="Пока тихо"
          text="Опишите цель своими словами — модель разложит её на шаги и предложит, что важнее. Или запишите сами, если уже знаете первый ход."
          action={<Button onClick={() => setAiOpen(true)}>Собрать шаги</Button>}
        />
      ) : (
        <div className="grid gap-4">
          {visible.map((goal) => {
            const linked = tasks.filter((task) => task.goalId === goal.id);
            const progress = goalProgress(goal.id, tasks);
            return (
              <Card key={goal.id}>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-sm text-muted">{goal.kind === "dream" ? "Мечта" : "Цель"}</p>
                    <h2 className="font-display text-3xl leading-tight">{goal.title}</h2>
                  </div>
                  <p className="tabular-nums text-sm text-muted">{progress}%</p>
                </div>
                {goal.description ? <p className="mt-2 text-muted">{goal.description}</p> : null}
                {goal.targetDate ? <p className="mt-2 text-sm text-muted">К {goal.targetDate}</p> : null}
                <div className="mt-4">
                  <Meter value={progress} label={`Прогресс: ${goal.title}`} />
                </div>
                <ul className="mt-4 divide-y divide-line">
                  {linked.map((task) => (
                    <li key={task.id} className="flex items-center justify-between gap-3 py-2 text-sm">
                      <span className={task.done ? "text-muted line-through" : ""}>{task.title}</span>
                      <span className="shrink-0 text-muted">{PRIORITY_LABEL[task.priority]}</span>
                    </li>
                  ))}
                </ul>
                <StepForm goalId={goal.id} onAdd={addTask} />
                <div className="mt-3">
                  <DeleteButton
                    label="Удалить цель"
                    onConfirm={() => {
                      deleteGoal(goal.id);
                      toast("Цель удалена, задачи остались в списке");
                    }}
                  />
                </div>
              </Card>
            );
          })}
        </div>
      )}
      <ManualGoal
        open={manual}
        onClose={() => setManual(false)}
        onSave={(input) => {
          const id = addGoal(input);
          if (!id) return;
          if (input.firstStep.trim()) {
            addTask({
              title: input.firstStep,
              goalId: id,
              priority: "high",
              remind: "morning",
              energy: input.energy,
            });
          }
          setManual(false);
          toast("Записано");
        }}
      />
      <AiGoal
        open={aiOpen}
        onClose={() => setAiOpen(false)}
        onSave={(plan) => {
          addPlannedGoal({
            title: plan.title,
            description: plan.summary,
            kind: plan.kind,
            targetDate: plan.targetDate,
            steps: plan.steps,
          });
          setAiOpen(false);
          toast("Цель и шаги на месте");
        }}
      />
    </div>
  );
}

function StepForm({
  goalId,
  onAdd,
}: {
  goalId: string;
  onAdd: (input: { title: string; goalId: string; priority: Priority }) => void;
}) {
  const [title, setTitle] = useState("");
  return (
    <form
      className="mt-4 flex flex-col gap-2 sm:flex-row"
      onSubmit={(event) => {
        event.preventDefault();
        if (!title.trim()) return;
        onAdd({ title, goalId, priority: "medium" });
        setTitle("");
      }}
    >
      <Field
        value={title}
        onChange={(event) => setTitle(event.target.value)}
        placeholder="Ещё один шаг"
        aria-label="Новый шаг"
      />
      <Button type="submit" variant="quiet">
        Добавить шаг
      </Button>
    </form>
  );
}

function DeleteButton({ label, onConfirm }: { label: string; onConfirm: () => void }) {
  const [sure, setSure] = useState(false);
  if (!sure) {
    return (
      <Button variant="danger" onClick={() => setSure(true)}>
        {label}
      </Button>
    );
  }
  return (
    <div className="flex flex-wrap gap-2">
      <Button variant="danger" onClick={onConfirm}>
        Точно удалить
      </Button>
      <Button variant="ghost" onClick={() => setSure(false)}>
        Оставить
      </Button>
    </div>
  );
}

function ManualGoal({
  open,
  onClose,
  onSave,
}: {
  open: boolean;
  onClose: () => void;
  onSave: (input: {
    title: string;
    description: string;
    kind: GoalKind;
    targetDate?: string;
    firstStep: string;
    energy: "any" | "morning" | "day" | "evening";
  }) => void;
}) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [kind, setKind] = useState<GoalKind>("goal");
  const [targetDate, setTargetDate] = useState("");
  const [firstStep, setFirstStep] = useState("");
  const [energy, setEnergy] = useState<"any" | "morning" | "day" | "evening">("any");

  return (
    <Modal open={open} title="Новая запись" onClose={onClose}>
      <form
        className="grid gap-3"
        onSubmit={(event) => {
          event.preventDefault();
          onSave({ title, description, kind, targetDate, firstStep, energy });
          setTitle("");
          setDescription("");
          setFirstStep("");
        }}
      >
        <div className="flex gap-2">
          <Button type="button" variant={kind === "goal" ? "primary" : "quiet"} onClick={() => setKind("goal")}>
            Цель
          </Button>
          <Button type="button" variant={kind === "dream" ? "primary" : "quiet"} onClick={() => setKind("dream")}>
            Мечта
          </Button>
        </div>
        <div>
          <Label htmlFor="goal-title">Название</Label>
          <Field id="goal-title" value={title} onChange={(event) => setTitle(event.target.value)} required />
        </div>
        <div>
          <Label htmlFor="goal-desc">Зачем это вам</Label>
          <Area id="goal-desc" value={description} onChange={(event) => setDescription(event.target.value)} />
        </div>
        <div>
          <Label htmlFor="goal-date">К какой дате, если есть</Label>
          <Field id="goal-date" type="date" value={targetDate} onChange={(event) => setTargetDate(event.target.value)} />
        </div>
        <div>
          <Label htmlFor="goal-step">Первый шаг</Label>
          <Field id="goal-step" value={firstStep} onChange={(event) => setFirstStep(event.target.value)} />
        </div>
        <div>
          <Label htmlFor="goal-energy">Когда лучше делать</Label>
          <Select id="goal-energy" value={energy} onChange={(event) => setEnergy(event.target.value as typeof energy)}>
            {Object.entries(ENERGY_LABEL).map(([id, label]) => (
              <option key={id} value={id}>
                {label}
              </option>
            ))}
          </Select>
        </div>
        <Button type="submit">Сохранить</Button>
      </form>
    </Modal>
  );
}

function AiGoal({ open, onClose, onSave }: { open: boolean; onClose: () => void; onSave: (plan: GoalPlan) => void }) {
  const plan = useServerFn(planGoal);
  const [description, setDescription] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [draft, setDraft] = useState<GoalPlan | null>(null);

  return (
    <Modal
      open={open}
      title="Собрать шаги"
      onClose={() => {
        setError("");
        onClose();
      }}
    >
      {!draft ? (
        <form
          className="grid gap-3"
          onSubmit={async (event) => {
            event.preventDefault();
            setError("");
            if (description.trim().length < 8) {
              setError("Напишите чуть подробнее — пару предложений достаточно.");
              return;
            }
            setBusy(true);
            try {
              const result = await plan({ data: { description } });
              if (!result.ok) setError(result.error);
              else setDraft(result.plan);
            } catch {
              setError("Не вышло связаться с моделью. Запишите цель вручную.");
            } finally {
              setBusy(false);
            }
          }}
        >
          <p className="text-sm text-muted">
            Опишите цель или мечту. Модель предложит конкретные шаги и приоритеты — их можно поправить перед сохранением.
          </p>
          <Area
            value={description}
            onChange={(event) => setDescription(event.target.value)}
            placeholder="Хочу через полгода спокойно говорить на созвонах и не переводить каждое слово в голове"
            aria-label="Описание цели"
          />
          {error ? <p className="text-sm text-accent">{error}</p> : null}
          <Button type="submit" disabled={busy}>
            {busy ? "Собираю шаги…" : "Собрать шаги"}
          </Button>
        </form>
      ) : (
        <form
          className="grid gap-3"
          onSubmit={(event) => {
            event.preventDefault();
            onSave(draft);
            setDraft(null);
            setDescription("");
          }}
        >
          <p className="text-sm text-muted">Поправьте, если чувствуете иначе. Потом шаги станут задачами.</p>
          <Field value={draft.title} onChange={(event) => setDraft({ ...draft, title: event.target.value })} aria-label="Название" />
          <Area
            value={draft.summary}
            onChange={(event) => setDraft({ ...draft, summary: event.target.value })}
            aria-label="Зачем"
          />
          <div className="flex gap-2">
            <Button type="button" variant={draft.kind === "goal" ? "primary" : "quiet"} onClick={() => setDraft({ ...draft, kind: "goal" })}>
              Цель
            </Button>
            <Button type="button" variant={draft.kind === "dream" ? "primary" : "quiet"} onClick={() => setDraft({ ...draft, kind: "dream" })}>
              Мечта
            </Button>
          </div>
          <Field
            type="date"
            value={draft.targetDate ?? ""}
            aria-label="Дата"
            onChange={(event) => setDraft({ ...draft, targetDate: event.target.value || undefined })}
          />
          <ul className="grid gap-3">
            {draft.steps.map((step, index) => (
              <li key={index} className="grid gap-2 rounded-xl border border-line p-3">
                <Field
                  value={step.title}
                  aria-label={`Шаг ${index + 1}`}
                  onChange={(event) => {
                    const steps = draft.steps.slice();
                    steps[index] = { ...step, title: event.target.value };
                    setDraft({ ...draft, steps });
                  }}
                />
                <Select
                  value={step.priority}
                  aria-label="Приоритет"
                  onChange={(event) => {
                    const steps = draft.steps.slice();
                    steps[index] = { ...step, priority: event.target.value as Priority };
                    setDraft({ ...draft, steps });
                  }}
                >
                  {PRIORITIES.map((priority) => (
                    <option key={priority} value={priority}>
                      {PRIORITY_LABEL[priority]}
                    </option>
                  ))}
                </Select>
                {step.note ? <p className="text-sm text-muted">{step.note}</p> : null}
              </li>
            ))}
          </ul>
          <div className="flex flex-wrap gap-2">
            <Button type="submit">Сохранить цель</Button>
            <Button type="button" variant="ghost" onClick={() => setDraft(null)}>
              Описать заново
            </Button>
          </div>
        </form>
      )}
    </Modal>
  );
}
