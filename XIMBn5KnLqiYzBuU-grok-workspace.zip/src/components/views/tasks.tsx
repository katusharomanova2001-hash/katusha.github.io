import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Button, Card, Empty, Field, Label, Meter, PageHead, PriorityMark, Select, Area } from "@/components/ui";
import {
  ENERGY_LABEL,
  POINT_VALUES,
  PRIORITY_LABEL,
  REMIND_LABEL,
  endOfWeekKey,
  focusMinutes,
  priorityWeight,
  type Energy,
  type Priority,
  type RemindMode,
  type Task,
} from "@/lib/model";
import { usePlanner } from "@/lib/store";
import { useTodayKey } from "@/lib/use-today";

type Filter = "open" | "today" | "week" | "important" | "done";

const FILTERS: { id: Filter; label: string }[] = [
  { id: "open", label: "Открытые" },
  { id: "today", label: "Сегодня" },
  { id: "week", label: "Неделя" },
  { id: "important", label: "Важные" },
  { id: "done", label: "Готовые" },
];

export function TasksView() {
  const tasks = usePlanner((state) => state.tasks);
  const goals = usePlanner((state) => state.goals);
  const focusLog = usePlanner((state) => state.focusLog);
  const addTask = usePlanner((state) => state.addTask);
  const updateTask = usePlanner((state) => state.updateTask);
  const toggleTask = usePlanner((state) => state.toggleTask);
  const setProgress = usePlanner((state) => state.setProgress);
  const setAnchor = usePlanner((state) => state.setAnchor);
  const deleteTask = usePlanner((state) => state.deleteTask);
  const day = useTodayKey();
  const [filter, setFilter] = useState<Filter>("open");
  const [goalId, setGoalId] = useState("all");
  const [openId, setOpenId] = useState<string | null>(null);

  const visible = useMemo(() => {
    const weekEnd = day ? endOfWeekKey(day) : "";
    return tasks
      .filter((task) => (goalId === "all" ? true : task.goalId === goalId))
      .filter((task) => {
        if (filter === "done") return task.done;
        if (task.done) return false;
        if (filter === "today") {
          if (!day) return false;
          return task.due === day || task.anchor || Boolean(task.due && task.due < day);
        }
        if (filter === "week") {
          if (!day || !task.due) return false;
          return task.due >= day && task.due <= weekEnd;
        }
        if (filter === "important") return task.priority === "critical" || task.priority === "high";
        return true;
      })
      .slice()
      .sort((a, b) => {
        if (a.anchor !== b.anchor) return a.anchor ? -1 : 1;
        const ad = a.due ?? "9999-99-99";
        const bd = b.due ?? "9999-99-99";
        if (ad !== bd) return ad.localeCompare(bd);
        return priorityWeight(a.priority) - priorityWeight(b.priority);
      });
  }, [tasks, filter, goalId, day]);

  return (
    <div>
      <PageHead kicker="Что сделать" title="Задачи">
        <p className="text-sm text-muted">Важные можно двигать по проценту, пока не отметите готовыми.</p>
      </PageHead>
      <AddTask
        goals={goals.map((goal) => ({ id: goal.id, title: goal.title }))}
        onAdd={addTask}
      />
      <div className="mt-5 flex flex-wrap gap-2">
        {FILTERS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setFilter(item.id)}
            className={
              filter === item.id
                ? "min-h-11 rounded-xl bg-accent-soft px-4 text-sm font-semibold"
                : "min-h-11 rounded-xl px-4 text-sm text-muted"
            }
          >
            {item.label}
          </button>
        ))}
        <Select className="w-auto" value={goalId} aria-label="Фильтр по цели" onChange={(event) => setGoalId(event.target.value)}>
          <option value="all">Все цели</option>
          {goals.map((goal) => (
            <option key={goal.id} value={goal.id}>
              {goal.title}
            </option>
          ))}
        </Select>
      </div>
      {visible.length === 0 ? (
        <div className="mt-5">
          <Empty title="В этом срезе пусто" text="Смените фильтр или добавьте задачу сверху. За закрытие придут очки." />
        </div>
      ) : (
        <ul className="mt-5 grid gap-3">
          {visible.map((task) => (
            <li key={task.id}>
              <Card>
                <div className="flex items-start gap-3">
                  <input
                    type="checkbox"
                    className="mt-1 size-5 accent-accent"
                    checked={task.done}
                    aria-label={`Выполнено: ${task.title}`}
                    onChange={() => {
                      const delta = toggleTask(task.id);
                      if (delta > 0) toast(`+${delta} очков`);
                      if (delta < 0) toast("Отметку сняли");
                    }}
                  />
                  <div className="min-w-0 flex-1">
                    <button type="button" className="text-left" onClick={() => setOpenId(openId === task.id ? null : task.id)}>
                      <p className={task.done ? "font-medium text-muted line-through" : "font-medium"}>{task.title}</p>
                    </button>
                    <p className="mt-1 text-sm text-muted">
                      <PriorityMark priority={task.priority} />
                      {task.due ? ` · ${task.due}${task.dueTime ? ` ${task.dueTime}` : ""}` : ""}
                      {task.energy !== "any" ? ` · ${ENERGY_LABEL[task.energy]}` : ""}
                      {focusMinutes(focusLog, task.id) > 0 ? ` · ${focusMinutes(focusLog, task.id)} мин фокуса` : ""}
                      {!task.done ? ` · ${POINT_VALUES[task.priority]} очков` : ""}
                    </p>
                    {!task.done && (task.priority === "critical" || task.priority === "high") ? (
                      <label className="mt-3 block text-sm text-muted">
                        Сделано {task.progress}%
                        <input
                          type="range"
                          min={0}
                          max={100}
                          value={task.progress}
                          aria-label={`Прогресс: ${task.title}`}
                          className="mt-1 w-full accent-accent"
                          onChange={(event) => setProgress(task.id, Number(event.target.value))}
                        />
                        <Meter value={task.progress} label={`Прогресс задачи ${task.title}`} />
                      </label>
                    ) : null}
                    {openId === task.id ? (
                      <TaskEditor
                        task={task}
                        goals={goals.map((goal) => ({ id: goal.id, title: goal.title }))}
                        onChange={(patch) => updateTask(task.id, patch)}
                        onAnchor={() => setAnchor(task.id)}
                        onDelete={() => deleteTask(task.id)}
                      />
                    ) : null}
                  </div>
                </div>
              </Card>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function AddTask({
  goals,
  onAdd,
}: {
  goals: { id: string; title: string }[];
  onAdd: (input: Partial<Task> & Pick<Task, "title">) => void;
}) {
  const [title, setTitle] = useState("");
  const [priority, setPriority] = useState<Priority>("medium");
  const [due, setDue] = useState("");
  const [dueTime, setDueTime] = useState("");
  const [goalId, setGoalId] = useState("");
  const [remind, setRemind] = useState<RemindMode>("morning");
  const [energy, setEnergy] = useState<Energy>("any");
  const [notes, setNotes] = useState("");
  const [more, setMore] = useState(false);

  return (
    <Card>
      <form
        className="grid gap-3"
        onSubmit={(event) => {
          event.preventDefault();
          if (!title.trim()) return;
          onAdd({ title, priority, due, dueTime, goalId: goalId || undefined, remind, energy, notes });
          setTitle("");
          setNotes("");
        }}
      >
        <Label htmlFor="task-title">Новая задача</Label>
        <div className="flex flex-col gap-2 sm:flex-row">
          <Field id="task-title" value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Что нужно сделать" />
          <Button type="submit">Добавить</Button>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <Select value={priority} aria-label="Важность" onChange={(event) => setPriority(event.target.value as Priority)}>
            {(Object.keys(PRIORITY_LABEL) as Priority[]).map((id) => (
              <option key={id} value={id}>
                {PRIORITY_LABEL[id]}
              </option>
            ))}
          </Select>
          <Field type="date" value={due} aria-label="Срок" onChange={(event) => setDue(event.target.value)} />
        </div>
        <button type="button" className="min-h-11 text-left text-sm font-semibold text-accent" onClick={() => setMore((value) => !value)}>
          {more ? "Скрыть подробности" : "Срок, напоминание, цель"}
        </button>
        {more ? (
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <Label htmlFor="task-time">Время срока</Label>
              <Field id="task-time" type="time" value={dueTime} onChange={(event) => setDueTime(event.target.value)} />
            </div>
            <div>
              <Label htmlFor="task-remind">Напоминание</Label>
              <Select id="task-remind" value={remind} onChange={(event) => setRemind(event.target.value as RemindMode)}>
                {(Object.keys(REMIND_LABEL) as RemindMode[]).map((id) => (
                  <option key={id} value={id}>
                    {REMIND_LABEL[id]}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <Label htmlFor="task-energy">Когда по силам</Label>
              <Select id="task-energy" value={energy} onChange={(event) => setEnergy(event.target.value as Energy)}>
                {(Object.keys(ENERGY_LABEL) as Energy[]).map((id) => (
                  <option key={id} value={id}>
                    {ENERGY_LABEL[id]}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <Label htmlFor="task-goal">Цель</Label>
              <Select id="task-goal" value={goalId} onChange={(event) => setGoalId(event.target.value)}>
                <option value="">Без цели</option>
                {goals.map((goal) => (
                  <option key={goal.id} value={goal.id}>
                    {goal.title}
                  </option>
                ))}
              </Select>
            </div>
            <div className="sm:col-span-2">
              <Label htmlFor="task-notes">Заметка</Label>
              <Area id="task-notes" value={notes} onChange={(event) => setNotes(event.target.value)} />
            </div>
          </div>
        ) : null}
      </form>
    </Card>
  );
}

function TaskEditor({
  task,
  goals,
  onChange,
  onAnchor,
  onDelete,
}: {
  task: Task;
  goals: { id: string; title: string }[];
  onChange: (patch: Partial<Task>) => void;
  onAnchor: () => void;
  onDelete: () => void;
}) {
  const [sure, setSure] = useState(false);
  return (
    <div className="mt-4 grid gap-3 border-t border-line pt-4">
      <Field value={task.title} aria-label="Название" onChange={(event) => onChange({ title: event.target.value })} />
      <Area value={task.notes} aria-label="Заметка" onChange={(event) => onChange({ notes: event.target.value })} />
      <div className="grid gap-3 sm:grid-cols-2">
        <Select value={task.priority} aria-label="Важность" onChange={(event) => onChange({ priority: event.target.value as Priority })}>
          {(Object.keys(PRIORITY_LABEL) as Priority[]).map((id) => (
            <option key={id} value={id}>
              {PRIORITY_LABEL[id]}
            </option>
          ))}
        </Select>
        <Select value={task.remind} aria-label="Напоминание" onChange={(event) => onChange({ remind: event.target.value as RemindMode })}>
          {(Object.keys(REMIND_LABEL) as RemindMode[]).map((id) => (
            <option key={id} value={id}>
              {REMIND_LABEL[id]}
            </option>
          ))}
        </Select>
        <Field type="date" value={task.due ?? ""} aria-label="Дата" onChange={(event) => onChange({ due: event.target.value || undefined })} />
        <Field type="time" value={task.dueTime ?? ""} aria-label="Время" onChange={(event) => onChange({ dueTime: event.target.value || undefined })} />
        <Select value={task.energy} aria-label="Время дня" onChange={(event) => onChange({ energy: event.target.value as Energy })}>
          {(Object.keys(ENERGY_LABEL) as Energy[]).map((id) => (
            <option key={id} value={id}>
              {ENERGY_LABEL[id]}
            </option>
          ))}
        </Select>
        <Select value={task.goalId ?? ""} aria-label="Цель" onChange={(event) => onChange({ goalId: event.target.value || undefined })}>
          <option value="">Без цели</option>
          {goals.map((goal) => (
            <option key={goal.id} value={goal.id}>
              {goal.title}
            </option>
          ))}
        </Select>
      </div>
      <div className="flex flex-wrap gap-2">
        <Button variant="quiet" onClick={onAnchor}>
          {task.anchor ? "Убрать с главного" : "Сделать главной на сегодня"}
        </Button>
        {sure ? (
          <Button
            variant="danger"
            onClick={() => {
              onDelete();
              toast("Задача удалена");
            }}
          >
            Точно удалить
          </Button>
        ) : (
          <Button variant="danger" onClick={() => setSure(true)}>
            Удалить
          </Button>
        )}
      </div>
    </div>
  );
}
