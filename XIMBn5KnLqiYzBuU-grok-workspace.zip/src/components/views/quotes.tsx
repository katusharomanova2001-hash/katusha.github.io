import { toast } from "sonner";
import { Button, Card, PageHead } from "@/components/ui";
import { usePlanner } from "@/lib/store";
import { cn } from "@/lib/utils";

export function QuotesView() {
  const quotes = usePlanner((state) => state.quotes);
  const points = usePlanner((state) => state.points);
  const active = usePlanner((state) => state.settings.activeQuoteId);
  const unlockQuote = usePlanner((state) => state.unlockQuote);
  const setActiveQuote = usePlanner((state) => state.setActiveQuote);

  return (
    <div>
      <PageHead kicker="Очки с закрытых задач" title="Цитаты">
        <p className="tabular-nums text-sm">
          <span className="font-semibold">{points}</span> <span className="text-muted">очков</span>
        </p>
      </PageHead>
      <p className="mb-5 max-w-2xl text-muted">
        Три фразы уже открыты. Остальные покупаются очками: срочная задача даёт 30, важная — 18, обычная — 10.
      </p>
      <ul className="grid gap-4">
        {quotes.map((quote) => {
          const current = quote.id === active && quote.unlocked;
          return (
            <li key={quote.id}>
              <Card className={cn(current && "border-accent")}>
                <blockquote className="font-display text-2xl italic leading-snug">{quote.text}</blockquote>
                <div className="mt-4 flex flex-wrap items-center gap-2">
                  {quote.cost === 0 ? <span className="text-sm text-muted">Уже ваша</span> : <span className="tabular-nums text-sm">{quote.cost} очков</span>}
                  {current ? <span className="text-sm font-semibold text-accent">На главном экране</span> : null}
                  {quote.unlocked && !current ? (
                    <Button variant="quiet" onClick={() => setActiveQuote(quote.id)}>
                      На главный экран
                    </Button>
                  ) : null}
                  {!quote.unlocked ? (
                    <Button
                      onClick={() => {
                        const result = unlockQuote(quote.id);
                        if (result === "ok") toast("Цитата открыта и стоит на главном");
                        if (result === "poor") toast("Пока не хватает очков");
                      }}
                    >
                      Открыть
                    </Button>
                  ) : null}
                </div>
              </Card>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
