import { useEffect, useState } from "react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Card, IconButton, PageHead, PriorityMark } from "@/components/ui";
import { buildMonth, todayKey } from "@/lib/model";
import { usePlanner } from "@/lib/store";
import { useTodayKey } from "@/lib/use-today";
import { cn } from "@/lib/utils";

const WEEKDAYS = ["пн", "вт", "ср", "чт", "пт", "сб", "вс"];

export function CalendarView() {
  const day = useTodayKey();
  const tasks = usePlanner((state) => state.tasks);
  const scheduled = usePlanner((state) => state.scheduled);
  const toggleTask = usePlanner((state) => state.toggleTask);
  const [cursor, setCursor] = useState<Date | null>(null);
  const [selected, setSelected] = useState<string | null>(null);

  useEffect(() => {
    setCursor((current) => current ?? new Date());
  }, []);
  const year = cursor?.getFullYear() ?? 0;
  const month = cursor?.getMonth() ?? 0;
  const cells = buildMonth(year, month);
  const active = selected ?? day;
  const title = format(new Date(year, month, 1), "LLLL yyyy", { locale: ru }).replace(/^./, (letter) => letter.toUpperCase());
  const dayTasks = tasks.filter((task) => task.due === active);
  const dayFocus = scheduled.filter((item) => todayKey(new Date(item.start)) === active);

  return (
    <div>
      <PageHead kicker="Сроки и сессии" title="Календарь" />
      {!cursor ? (
        <Card>
          <p className="text-muted">Собираю месяц.</p>
        </Card>
      ) : (
        <>
          <Card>
            <div className="mb-4 flex items-center justify-between gap-3">
          <IconButton label="Предыдущий месяц" onClick={() => setCursor(new Date(year, month - 1, 1))}>
            <ChevronLeft className="size-5" />
          </IconButton>
          <h2 className="font-display text-3xl">{title}</h2>
          <IconButton label="Следующий месяц" onClick={() => setCursor(new Date(year, month + 1, 1))}>
            <ChevronRight className="size-5" />
          </IconButton>
        </div>
        <div className="grid grid-cols-7 gap-1 text-center text-sm text-muted">
          {WEEKDAYS.map((name) => (
            <div key={name} className="py-2">
              {name}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {cells.map((cell, index) => {
            if (!cell) return <div key={`empty-${index}`} />;
            const count = tasks.filter((task) => task.due === cell && !task.done).length;
            const focus = scheduled.some((item) => !item.done && todayKey(new Date(item.start)) === cell);
            const number = Number(cell.slice(-2));
            return (
              <button
                key={cell}
                type="button"
                onClick={() => setSelected(cell)}
                className={cn(
                  "flex min-h-14 flex-col items-center justify-center rounded-xl text-sm",
                  cell === active ? "bg-accent text-on-accent" : "hover:bg-surface-2",
                  cell === day && cell !== active && "border border-accent",
                )}
              >
                <span className="tabular-nums">{number}</span>
                <span className="mt-1 flex gap-1" aria-hidden>
                  {count > 0 ? <span className={cn("size-1.5 rounded-full", cell === active ? "bg-on-accent" : "bg-accent")} /> : null}
                  {focus ? <span className={cn("size-1.5 rounded-full", cell === active ? "bg-on-accent" : "bg-ink")} /> : null}
                </span>
              </button>
            );
          })}
        </div>
      </Card>
      <Card className="mt-5">
        <h2 className="font-display text-3xl">
          {active
            ? format(parse(active), "EEEE, d MMMM", { locale: ru }).replace(/^./, (letter) => letter.toUpperCase())
            : "День"}
        </h2>
        <ul className="mt-3 divide-y divide-line">
          {dayTasks.map((task) => (
            <li key={task.id} className="flex items-start gap-3 py-3">
              <input
                type="checkbox"
                className="mt-1 size-5 accent-accent"
                checked={task.done}
                aria-label={`Выполнено: ${task.title}`}
                onChange={() => toggleTask(task.id)}
              />
              <div>
                <p className={task.done ? "text-muted line-through" : ""}>{task.title}</p>
                <PriorityMark priority={task.priority} />
              </div>
            </li>
          ))}
          {dayFocus.map((item) => (
            <li key={item.id} className="py-3 text-sm">
              <p className="font-medium">{item.title}</p>
              <p className="text-muted">
                Фокус · {format(new Date(item.start), "HH:mm")} · {item.minutes} мин
                {item.done ? " · прошло" : ""}
              </p>
            </li>
          ))}
          {dayTasks.length === 0 && dayFocus.length === 0 ? <li className="py-3 text-muted">В этот день пусто.</li> : null}
        </ul>
      </Card>
        </>
      )}
    </div>
  );
}

function parse(day: string) {
  const [y, m, d] = day.split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}
