import { useState, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  Bell,
  CalendarDays,
  ChartColumn,
  Compass,
  Gift,
  ListChecks,
  Printer,
  Quote,
  Settings,
  Sun,
  Timer,
  X,
} from "lucide-react";
import { Toaster } from "sonner";
import { SettingsDialog } from "@/components/settings-dialog";
import { Reminders, useHydratePlanner } from "@/components/reminders";
import { IconButton } from "@/components/ui";
import { usePlanner } from "@/lib/store";
import { useTodayKey } from "@/lib/use-today";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Сегодня", icon: Sun },
  { to: "/goals", label: "Цели", icon: Compass },
  { to: "/tasks", label: "Задачи", icon: ListChecks },
  { to: "/focus", label: "Фокус", icon: Timer },
  { to: "/calendar", label: "Календарь", icon: CalendarDays },
  { to: "/wishes", label: "Желания", icon: Gift },
  { to: "/insights", label: "Обзор", icon: ChartColumn },
  { to: "/print", label: "Печать", icon: Printer },
  { to: "/quotes", label: "Цитаты", icon: Quote },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  useHydratePlanner();
  const path = useRouterState({ select: (state) => state.location.pathname });
  const points = usePlanner((state) => state.points);
  const tasks = usePlanner((state) => state.tasks);
  const day = useTodayKey();
  const [more, setMore] = useState(false);
  const [settings, setSettings] = useState(false);
  const due = day ? tasks.filter((task) => !task.done && task.due && task.due <= day).length : 0;

  return (
    <div className="min-h-screen bg-bg text-ink">
      <aside className="no-print fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-line bg-surface px-4 py-6 md:flex">
        <Link to="/" className="mb-8 block px-2">
          <p className="font-display text-4xl leading-none text-ink">Светлица</p>
          <p className="mt-2 text-sm text-muted">личная мастерская</p>
        </Link>
        <nav className="flex flex-1 flex-col gap-1">
          {NAV.map((item) => (
            <NavLink key={item.to} to={item.to} label={item.label} icon={item.icon} path={path} />
          ))}
        </nav>
        <Link
          to="/quotes"
          className="mt-4 flex min-h-11 items-center justify-between rounded-xl bg-accent-soft px-3 text-sm"
        >
          <span className="text-muted">Очки</span>
          <span className="tabular-nums font-semibold">{points}</span>
        </Link>
      </aside>

      <div className="shell-main md:pl-60">
        <header className="no-print sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-line bg-bg/90 px-4 py-3 backdrop-blur md:px-8">
          <Link to="/" className="font-display text-2xl leading-none md:hidden">
            Светлица
          </Link>
          <p className="hidden text-sm text-muted md:block">Только у вас, в этом браузере</p>
          <div className="flex items-center gap-1">
            {due > 0 ? (
              <Link to="/tasks" className="inline-flex min-h-11 items-center gap-2 rounded-xl px-3 text-sm text-accent">
                <Bell className="size-4" aria-hidden />
                <span className="tabular-nums">{due}</span>
                <span className="sr-only">задач со сроком</span>
              </Link>
            ) : null}
            <span className="tabular-nums px-2 text-sm font-semibold md:hidden">{points}</span>
            <IconButton label="Настройки" onClick={() => setSettings(true)}>
              <Settings className="size-5" />
            </IconButton>
          </div>
        </header>
        <main className="mx-auto w-full max-w-5xl px-4 py-6 pb-28 md:px-8 md:pb-16">{children}</main>
      </div>

      <nav className="no-print fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface md:hidden">
        <div className="grid grid-cols-5">
          {NAV.slice(0, 4).map((item) => (
            <NavLink key={item.to} to={item.to} label={item.label} icon={item.icon} path={path} compact />
          ))}
          <button
            type="button"
            className="flex min-h-16 flex-col items-center justify-center gap-1 text-xs text-muted"
            onClick={() => setMore(true)}
          >
            <span className="text-sm font-semibold">Ещё</span>
          </button>
        </div>
      </nav>

      {more ? (
        <div className="fixed inset-0 z-40 md:hidden">
          <button type="button" aria-label="Закрыть меню" className="absolute inset-0 bg-ink/40" onClick={() => setMore(false)} />
          <div className="absolute inset-x-0 bottom-0 rounded-t-2xl border border-line bg-surface p-4">
            <div className="mb-2 flex items-center justify-between">
              <p className="font-display text-3xl">Ещё</p>
              <IconButton label="Закрыть" onClick={() => setMore(false)}>
                <X className="size-5" />
              </IconButton>
            </div>
            <div className="grid gap-1">
              {NAV.slice(4).map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  label={item.label}
                  icon={item.icon}
                  path={path}
                  onClick={() => setMore(false)}
                />
              ))}
              <button
                type="button"
                className="flex min-h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium"
                onClick={() => {
                  setMore(false);
                  setSettings(true);
                }}
              >
                <Settings className="size-5" />
                Настройки
              </button>
            </div>
          </div>
        </div>
      ) : null}

      <SettingsDialog open={settings} onClose={() => setSettings(false)} />
      <Reminders />
      <Toaster
        position="top-center"
        toastOptions={{
          style: {
            background: "var(--color-surface)",
            color: "var(--color-ink)",
            border: "1px solid var(--color-line)",
          },
        }}
      />
    </div>
  );
}

function NavLink({
  to,
  label,
  icon: Icon,
  path,
  compact = false,
  onClick,
}: {
  to: (typeof NAV)[number]["to"];
  label: string;
  icon: (typeof NAV)[number]["icon"];
  path: string;
  compact?: boolean;
  onClick?: () => void;
}) {
  const active = to === "/" ? path === "/" : path.startsWith(to);
  return (
    <Link
      to={to}
      onClick={onClick}
      className={cn(
        compact
          ? "flex min-h-16 flex-col items-center justify-center gap-1 px-1 text-xs"
          : "flex min-h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium",
        active ? "text-accent" : "text-muted",
        !compact && active && "bg-accent-soft text-ink",
        !compact && !active && "hover:bg-surface-2 hover:text-ink",
      )}
    >
      <Icon className={cn("size-5", active && compact && "text-accent")} strokeWidth={1.75} aria-hidden />
      {label}
    </Link>
  );
}
