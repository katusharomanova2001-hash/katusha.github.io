import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import {
  blankTask,
  DEFAULT_SETTINGS,
  elapsedMs,
  mergeQuotes,
  POINT_VALUES,
  todayKey,
  uid,
  type ActiveFocus,
  type AnalyticsEvent,
  type Energy,
  type EventType,
  type FocusEntry,
  type Goal,
  type GoalKind,
  type PlannerShape,
  type Priority,
  type RemindMode,
  type ScheduledFocus,
  type Settings,
  type Task,
  type WeekNote,
  type Wish,
} from "@/lib/model";

export type Planner = PlannerShape & {
  setSettings: (patch: Partial<Settings>) => void;
  addGoal: (input: { title: string; description: string; kind: GoalKind; targetDate?: string }) => string | null;
  addPlannedGoal: (input: {
    title: string;
    description: string;
    kind: GoalKind;
    targetDate?: string;
    steps: { title: string; priority: Priority; note: string }[];
  }) => void;
  deleteGoal: (id: string) => void;
  addTask: (input: Partial<Task> & Pick<Task, "title">) => void;
  updateTask: (id: string, patch: Partial<Task>) => void;
  toggleTask: (id: string) => number;
  setProgress: (id: string, progress: number) => void;
  setAnchor: (id: string) => void;
  deleteTask: (id: string) => void;
  addWish: (input: Omit<Wish, "id" | "createdAt" | "bought">) => void;
  updateWish: (id: string, patch: Partial<Wish>) => void;
  deleteWish: (id: string) => void;
  unlockQuote: (id: string) => "ok" | "poor" | "missing" | "already";
  setActiveQuote: (id: string) => void;
  addWater: (day: string, delta: number) => void;
  setWeekNote: (key: string, patch: Partial<WeekNote>) => void;
  startFocus: (input: {
    title: string;
    taskId?: string;
    plannedMinutes: number;
    scheduleId?: string;
  }) => boolean;
  pauseFocus: () => void;
  resumeFocus: () => void;
  finishFocus: () => number;
  discardFocus: () => void;
  scheduleFocus: (input: Omit<ScheduledFocus, "id" | "done">) => void;
  deleteScheduled: (id: string) => void;
  markFired: (key: string) => boolean;
  importSnapshot: (raw: unknown) => boolean;
};

function event(type: EventType, label: string): AnalyticsEvent {
  const at = new Date();
  return { id: uid(), type, at: at.toISOString(), day: todayKey(at), label };
}

function emptyWeek(): WeekNote {
  return { moved: "", drop: "", focus: "" };
}

function mergeState(persisted: unknown, current: Planner): Planner {
  if (!persisted || typeof persisted !== "object") return current;
  const saved = persisted as Partial<PlannerShape>;
  const settings = { ...DEFAULT_SETTINGS, ...(saved.settings ?? {}) };
  const quotes = mergeQuotes(saved.quotes);
  if (!quotes.some((quote) => quote.id === settings.activeQuoteId && quote.unlocked)) {
    settings.activeQuoteId = quotes.find((quote) => quote.unlocked)?.id ?? "q1";
  }
  return {
    ...current,
    goals: Array.isArray(saved.goals) ? saved.goals : [],
    tasks: Array.isArray(saved.tasks) ? saved.tasks : [],
    focusLog: Array.isArray(saved.focusLog) ? saved.focusLog : [],
    scheduled: Array.isArray(saved.scheduled) ? saved.scheduled : [],
    wishes: Array.isArray(saved.wishes) ? saved.wishes : [],
    events: Array.isArray(saved.events) ? saved.events : [],
    water: saved.water && typeof saved.water === "object" ? saved.water : {},
    weekNotes: saved.weekNotes && typeof saved.weekNotes === "object" ? saved.weekNotes : {},
    fired: Array.isArray(saved.fired) ? saved.fired : [],
    points: typeof saved.points === "number" ? saved.points : 0,
    active: saved.active ?? null,
    quotes,
    settings,
  };
}

function memoryStorage() {
  const bag = new Map<string, string>();
  return {
    getItem: (name: string) => bag.get(name) ?? null,
    setItem: (name: string, value: string) => {
      bag.set(name, value);
    },
    removeItem: (name: string) => {
      bag.delete(name);
    },
  };
}

export const usePlanner = create<Planner>()(
  persist(
    (set, get) => ({
      goals: [],
      tasks: [],
      focusLog: [],
      scheduled: [],
      wishes: [],
      quotes: mergeQuotes(undefined),
      points: 0,
      events: [],
      water: {},
      weekNotes: {},
      settings: DEFAULT_SETTINGS,
      active: null,
      fired: [],

      setSettings: (patch) => set((state) => ({ settings: { ...state.settings, ...patch } })),

      addGoal: (input) => {
        const title = input.title.trim();
        if (!title) return null;
        const goal: Goal = {
          id: uid(),
          title,
          description: input.description.trim(),
          kind: input.kind,
          createdAt: new Date().toISOString(),
          targetDate: input.targetDate || undefined,
        };
        set((state) => ({
          goals: [goal, ...state.goals],
          events: [event("goal_created", goal.title), ...state.events].slice(0, 400),
        }));
        return goal.id;
      },

      addPlannedGoal: (input) => {
        const title = input.title.trim();
        if (!title) return;
        const goal: Goal = {
          id: uid(),
          title,
          description: input.description.trim(),
          kind: input.kind,
          createdAt: new Date().toISOString(),
          targetDate: input.targetDate || undefined,
        };
        const tasks = input.steps
          .filter((step) => step.title.trim())
          .map((step) =>
            blankTask({
              title: step.title,
              notes: step.note,
              goalId: goal.id,
              priority: step.priority,
              remind: "morning",
            }),
          );
        const taskEvents = tasks.map((task) => event("task_created", task.title));
        set((state) => ({
          goals: [goal, ...state.goals],
          tasks: [...tasks, ...state.tasks],
          events: [event("goal_created", goal.title), ...taskEvents, ...state.events].slice(0, 400),
        }));
      },

      deleteGoal: (id) =>
        set((state) => ({
          goals: state.goals.filter((goal) => goal.id !== id),
          tasks: state.tasks.map((task) => (task.goalId === id ? { ...task, goalId: undefined } : task)),
        })),

      addTask: (input) => {
        const task = blankTask(input);
        if (!task.title) return;
        set((state) => ({
          tasks: [task, ...state.tasks],
          events: [event("task_created", task.title), ...state.events].slice(0, 400),
        }));
      },

      updateTask: (id, patch) =>
        set((state) => ({
          tasks: state.tasks.map((task) => (task.id === id ? { ...task, ...patch, id: task.id } : task)),
        })),

      toggleTask: (id) => {
        let delta = 0;
        set((state) => {
          const task = state.tasks.find((item) => item.id === id);
          if (!task) return state;
          if (!task.done) {
            delta = POINT_VALUES[task.priority];
            const completed = event("task_completed", task.title);
            return {
              points: state.points + delta,
              tasks: state.tasks.map((item) =>
                item.id === id
                  ? {
                      ...item,
                      done: true,
                      progress: 100,
                      completedAt: completed.at,
                      completedEventId: completed.id,
                      pointsAwarded: delta,
                      anchor: false,
                    }
                  : item,
              ),
              events: [completed, ...state.events].slice(0, 400),
            };
          }
          delta = -task.pointsAwarded;
          return {
            points: Math.max(0, state.points - task.pointsAwarded),
            tasks: state.tasks.map((item) =>
              item.id === id
                ? { ...item, done: false, completedAt: undefined, completedEventId: undefined, pointsAwarded: 0 }
                : item,
            ),
            events: state.events.filter((item) => item.id !== task.completedEventId),
          };
        });
        return delta;
      },

      setProgress: (id, progress) =>
        set((state) => ({
          tasks: state.tasks.map((task) =>
            task.id === id ? { ...task, progress: Math.max(0, Math.min(100, Math.round(progress))) } : task,
          ),
        })),

      setAnchor: (id) =>
        set((state) => ({
          tasks: state.tasks.map((task) => ({
            ...task,
            anchor: task.id === id ? !task.anchor : false,
          })),
        })),

      deleteTask: (id) => set((state) => ({ tasks: state.tasks.filter((task) => task.id !== id) })),

      addWish: (input) => {
        const title = input.title.trim();
        if (!title) return;
        const wish: Wish = {
          id: uid(),
          title,
          url: input.url.trim(),
          note: input.note.trim(),
          price: input.price.trim(),
          image: input.image,
          createdAt: new Date().toISOString(),
          bought: false,
        };
        set((state) => ({ wishes: [wish, ...state.wishes] }));
      },

      updateWish: (id, patch) =>
        set((state) => ({
          wishes: state.wishes.map((wish) => (wish.id === id ? { ...wish, ...patch } : wish)),
        })),

      deleteWish: (id) => set((state) => ({ wishes: state.wishes.filter((wish) => wish.id !== id) })),

      unlockQuote: (id) => {
        const state = get();
        const quote = state.quotes.find((item) => item.id === id);
        if (!quote) return "missing";
        if (quote.unlocked) return "already";
        if (state.points < quote.cost) return "poor";
        set({
          points: state.points - quote.cost,
          quotes: state.quotes.map((item) => (item.id === id ? { ...item, unlocked: true } : item)),
          settings: { ...state.settings, activeQuoteId: id },
        });
        return "ok";
      },

      setActiveQuote: (id) => {
        const quote = get().quotes.find((item) => item.id === id && item.unlocked);
        if (!quote) return;
        set((state) => ({ settings: { ...state.settings, activeQuoteId: id } }));
      },

      addWater: (day, delta) =>
        set((state) => {
          const next = Math.max(0, (state.water[day] ?? 0) + delta);
          return { water: { ...state.water, [day]: next } };
        }),

      setWeekNote: (key, patch) =>
        set((state) => ({
          weekNotes: {
            ...state.weekNotes,
            [key]: { ...emptyWeek(), ...state.weekNotes[key], ...patch },
          },
        })),

      startFocus: (input) => {
        if (get().active) return false;
        const title = input.title.trim() || "Фокус";
        const active: ActiveFocus = {
          title,
          taskId: input.taskId,
          plannedMinutes: Math.max(1, input.plannedMinutes),
          startedAt: Date.now(),
          accumulatedMs: 0,
          running: true,
          scheduleId: input.scheduleId,
        };
        set((state) => ({
          active,
          events: [event("focus_started", title), ...state.events].slice(0, 400),
        }));
        return true;
      },

      pauseFocus: () => {
        const active = get().active;
        if (!active?.running) return;
        set({
          active: {
            ...active,
            running: false,
            accumulatedMs: elapsedMs(active),
          },
        });
      },

      resumeFocus: () => {
        const active = get().active;
        if (!active || active.running) return;
        set({ active: { ...active, running: true, startedAt: Date.now() } });
      },

      finishFocus: () => {
        const active = get().active;
        if (!active) return 0;
        const minutes = Math.round(elapsedMs(active) / 60_000);
        const at = new Date();
        set((state) => {
          const entry: FocusEntry[] =
            minutes >= 1
              ? [
                  {
                    id: uid(),
                    taskId: active.taskId,
                    title: active.title,
                    minutes,
                    at: at.toISOString(),
                    day: todayKey(at),
                  },
                  ...state.focusLog,
                ].slice(0, 400)
              : state.focusLog;
          return {
            active: null,
            focusLog: entry,
            scheduled: active.scheduleId
              ? state.scheduled.map((item) => (item.id === active.scheduleId ? { ...item, done: true } : item))
              : state.scheduled,
          };
        });
        return minutes;
      },

      discardFocus: () => set({ active: null }),

      scheduleFocus: (input) => {
        const title = input.title.trim();
        if (!title || !input.start) return;
        const item: ScheduledFocus = {
          id: uid(),
          title,
          taskId: input.taskId,
          start: input.start,
          minutes: Math.max(1, input.minutes),
          remindMinutes: input.remindMinutes,
          done: false,
        };
        set((state) => ({ scheduled: [...state.scheduled, item] }));
      },

      deleteScheduled: (id) =>
        set((state) => ({ scheduled: state.scheduled.filter((item) => item.id !== id) })),

      markFired: (key) => {
        if (get().fired.includes(key)) return false;
        set((state) => ({ fired: [...state.fired, key].slice(-300) }));
        return true;
      },

      importSnapshot: (raw) => {
        if (!raw || typeof raw !== "object") return false;
        const body = raw as Record<string, unknown>;
        if (!Array.isArray(body.tasks) && !Array.isArray(body.goals) && !Array.isArray(body.wishes)) return false;
        set((state) => mergeState(raw, state));
        return true;
      },
    }),
    {
      name: "svetlitsa-v1",
      skipHydration: true,
      storage: createJSONStorage(() => (typeof window === "undefined" ? memoryStorage() : window.localStorage)),
      partialize: (state) => ({
        goals: state.goals,
        tasks: state.tasks,
        focusLog: state.focusLog,
        scheduled: state.scheduled,
        wishes: state.wishes,
        quotes: state.quotes,
        points: state.points,
        events: state.events,
        water: state.water,
        weekNotes: state.weekNotes,
        settings: state.settings,
        active: state.active,
        fired: state.fired,
      }),
      merge: (persisted, current) => mergeState(persisted, current),
    },
  ),
);

export type { Energy, Priority, RemindMode };
