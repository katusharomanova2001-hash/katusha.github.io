import { createServerFn } from "@tanstack/react-start";
import type { GoalKind, Priority } from "@/lib/model";

export type PlanStep = { title: string; priority: Priority; note: string };

export type GoalPlan = {
  title: string;
  summary: string;
  kind: GoalKind;
  targetDate?: string;
  steps: PlanStep[];
};

export type PlanResult = { ok: true; plan: GoalPlan } | { ok: false; error: string };

const PRIORITIES = new Set<Priority>(["critical", "high", "medium", "low", "someday"]);

let lastCall = 0;

function asPriority(value: unknown): Priority {
  const raw = String(value ?? "")
    .trim()
    .toLowerCase();
  const mapped: Record<string, Priority> = {
    critical: "critical",
    high: "high",
    medium: "medium",
    low: "low",
    someday: "someday",
    срочно: "critical",
    важно: "high",
    нужно: "medium",
    позже: "low",
    "когда-нибудь": "someday",
  };
  const priority = mapped[raw];
  return priority && PRIORITIES.has(priority) ? priority : "medium";
}

function asKind(value: unknown): GoalKind {
  const raw = String(value ?? "").toLowerCase();
  if (raw.includes("dream") || raw.includes("мечт")) return "dream";
  return "goal";
}

function parsePlan(text: string, fallbackTitle: string): GoalPlan | null {
  const trimmed = text.trim();
  const fenced = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/);
  const raw = fenced?.[1] ?? trimmed;
  let data: unknown;
  try {
    data = JSON.parse(raw);
  } catch {
    return null;
  }
  if (!data || typeof data !== "object") return null;
  const body = data as Record<string, unknown>;
  const stepsRaw = Array.isArray(body.steps) ? body.steps : [];
  const steps = stepsRaw
    .map((step) => {
      const item = step && typeof step === "object" ? (step as Record<string, unknown>) : {};
      return {
        title: String(item.title ?? "").trim(),
        priority: asPriority(item.priority),
        note: String(item.note ?? "").trim(),
      };
    })
    .filter((step) => step.title)
    .slice(0, 8);
  if (!steps.length) return null;
  const title = String(body.title ?? "").trim() || fallbackTitle;
  const date = String(body.targetDate ?? "");
  return {
    title: title.slice(0, 120),
    summary: String(body.summary ?? "").trim().slice(0, 400),
    kind: asKind(body.kind),
    targetDate: /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : undefined,
    steps,
  };
}

async function complete(apiKey: string, description: string, jsonMode: boolean) {
  return fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "grok-4.5",
      temperature: 0.4,
      max_tokens: 900,
      ...(jsonMode ? { response_format: { type: "json_object" } } : {}),
      messages: [
        {
          role: "system",
          content:
            "Ты помощник по личному планированию. Верни только JSON без пояснений: " +
            '{"title":"короткое название","summary":"зачем это, одно предложение","kind":"goal или dream","targetDate":"YYYY-MM-DD или null","steps":[{"title":"конкретное действие","priority":"critical|high|medium|low|someday","note":"почему такой приоритет, до 12 слов"}]}. ' +
            "4–7 шагов, от ближайшего к дальнему. Шаги — действия, не лозунги. critical только если без этого всё стоит. kind=dream для образа жизни без жёсткого срока, иначе goal. Язык пользователя. Без emoji.",
        },
        { role: "user", content: description },
      ],
    }),
  });
}

export const planGoal = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const description =
      input && typeof input === "object" && "description" in input
        ? String((input as { description: unknown }).description ?? "")
        : "";
    return { description: description.trim().slice(0, 2000) };
  })
  .handler(async ({ data }): Promise<PlanResult> => {
    if (data.description.length < 8) {
      return { ok: false, error: "Опишите цель чуть подробнее — хотя бы пару фраз." };
    }
    const now = Date.now();
    if (now - lastCall < 8000) {
      return { ok: false, error: "Подождите пару секунд и попробуйте ещё раз." };
    }
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false, error: "Сейчас модель недоступна. Цель можно записать вручную." };
    lastCall = now;

    try {
      let response = await complete(apiKey, data.description, true);
      if (!response.ok && (response.status === 400 || response.status === 422)) {
        response = await complete(apiKey, data.description, false);
      }
      if (!response.ok) return { ok: false, error: "Модель не ответила. Попробуйте ещё раз чуть позже." };
      const body = (await response.json()) as { choices?: { message?: { content?: string } }[] };
      const text = body.choices?.[0]?.message?.content ?? "";
      const plan = parsePlan(text, data.description.slice(0, 80));
      if (!plan) return { ok: false, error: "Не удалось разобрать шаги. Попробуйте описать цель иначе." };
      return { ok: true, plan };
    } catch {
      return { ok: false, error: "Не вышло связаться с моделью. Проверьте сеть и попробуйте ещё раз." };
    }
  });
