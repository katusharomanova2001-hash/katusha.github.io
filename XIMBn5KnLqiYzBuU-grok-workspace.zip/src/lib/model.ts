export type Priority = "critical" | "high" | "medium" | "low" | "someday";
export type RemindMode = "off" | "at" | "m60" | "m180" | "d1" | "morning";
export type Energy = "any" | "morning" | "day" | "evening";
export type GoalKind = "goal" | "dream";

export type Goal = {
  id: string;
  title: string;
  description: string;
  kind: GoalKind;
  createdAt: string;
  targetDate?: string;
};

export type Task = {
  id: string;
  title: string;
  notes: string;
  goalId?: string;
  priority: Priority;
  due?: string;
  dueTime?: string;
  progress: number;
  done: boolean;
  createdAt: string;
  completedAt?: string;
  completedEventId?: string;
  pointsAwarded: number;
  remind: RemindMode;
  anchor: boolean;
  energy: Energy;
};

export type FocusEntry = {
  id: string;
  taskId?: string;
  title: string;
  minutes: number;
  at: string;
  day: string;
};

export type ScheduledFocus = {
  id: string;
  taskId?: string;
  title: string;
  start: string;
  minutes: number;
  remindMinutes: number;
  done: boolean;
};

export type ActiveFocus = {
  taskId?: string;
  title: string;
  plannedMinutes: number;
  startedAt: number;
  accumulatedMs: number;
  running: boolean;
  scheduleId?: string;
};

export type Wish = {
  id: string;
  title: string;
  url: string;
  note: string;
  price: string;
  image?: string;
  createdAt: string;
  bought: boolean;
};

export type Quote = {
  id: string;
  text: string;
  author: string;
  cost: number;
  unlocked: boolean;
};

export type EventType = "goal_created" | "task_created" | "focus_started" | "task_completed";

export type AnalyticsEvent = {
  id: string;
  type: EventType;
  at: string;
  day: string;
  label: string;
};

export type WeekNote = {
  moved: string;
  drop: string;
  focus: string;
};

export type Settings = {
  name: string;
  waterGoal: number;
  waterEveryMin: number;
  waterOn: boolean;
  notify: boolean;
  quietStart: string;
  quietEnd: string;
  activeQuoteId: string;
};

export const POINT_VALUES: Record<Priority, number> = {
  critical: 30,
  high: 18,
  medium: 10,
  low: 5,
  someday: 3,
};

export const PRIORITY_LABEL: Record<Priority, string> = {
  critical: "Срочно",
  high: "Важно",
  medium: "Нужно",
  low: "Можно позже",
  someday: "Когда-нибудь",
};

export const REMIND_LABEL: Record<RemindMode, string> = {
  off: "Без напоминания",
  at: "В момент срока",
  m60: "За час",
  m180: "За 3 часа",
  d1: "За день",
  morning: "Утром в день срока",
};

export const ENERGY_LABEL: Record<Energy, string> = {
  any: "Когда угодно",
  morning: "Утро",
  day: "День",
  evening: "Вечер",
};

export const QUOTE_CATALOG: Quote[] = [
  {
    id: "q1",
    cost: 0,
    unlocked: true,
    author: "Светлица",
    text: "Маленький шаг сегодня весит больше, чем идеальный план на потом.",
  },
  {
    id: "q2",
    cost: 0,
    unlocked: true,
    author: "Светлица",
    text: "Внимание — самая честная валюта дня. Тратьте её на то, что правда ваше.",
  },
  {
    id: "q3",
    cost: 0,
    unlocked: true,
    author: "Светлица",
    text: "Не всё сразу. Одна ясная задача уже двигает неделю.",
  },
  {
    id: "q4",
    cost: 20,
    unlocked: false,
    author: "Светлица",
    text: "Мечта без ближайшего шага — просто красивая мысль. Шаг можно сделать за двадцать минут.",
  },
  {
    id: "q5",
    cost: 20,
    unlocked: false,
    author: "Светлица",
    text: "Отдых тоже входит в план. Усталость плохо хранит обещания.",
  },
  {
    id: "q6",
    cost: 35,
    unlocked: false,
    author: "Светлица",
    text: "Если задача страшная, уменьшите её до того, что можно начать с чашкой чая рядом.",
  },
  {
    id: "q7",
    cost: 35,
    unlocked: false,
    author: "Светлица",
    text: "Вы не опаздываете к своей жизни. Вы как раз в том дне, который есть.",
  },
  {
    id: "q8",
    cost: 50,
    unlocked: false,
    author: "Светлица",
    text: "Сделанное молча тоже считается. Не каждая победа должна быть громкой.",
  },
  {
    id: "q9",
    cost: 50,
    unlocked: false,
    author: "Светлица",
    text: "Список желаний — не витрина вины. Это направление, куда смотреть, когда есть место.",
  },
  {
    id: "q10",
    cost: 70,
    unlocked: false,
    author: "Светлица",
    text: "Граница тоже цель: сказать нет лишнему, чтобы сказать да своему.",
  },
  {
    id: "q11",
    cost: 70,
    unlocked: false,
    author: "Светлица",
    text: "Вода, сон и один честный час фокуса чинят больше, чем ещё десять вкладок.",
  },
  {
    id: "q12",
    cost: 90,
    unlocked: false,
    author: "Светлица",
    text: "Пусть неделя будет короткой историей: что сдвинулось, что отпустить, чему отдать утро.",
  },
];

export const DEFAULT_SETTINGS: Settings = {
  name: "",
  waterGoal: 8,
  waterEveryMin: 90,
  waterOn: true,
  notify: false,
  quietStart: "22:00",
  quietEnd: "08:00",
  activeQuoteId: "q1",
};

export function uid() {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `id-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export function todayKey(d = new Date()) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function parseDay(isoDate: string, time = "09:00") {
  const [y, m, d] = isoDate.split("-").map(Number);
  const [hh, mm] = time.split(":").map(Number);
  return new Date(y, (m || 1) - 1, d || 1, hh || 0, mm || 0, 0, 0);
}

export function greet(d: Date) {
  const h = d.getHours();
  if (h < 5) return "Доброй ночи";
  if (h < 12) return "Доброе утро";
  if (h < 18) return "Добрый день";
  return "Добрый вечер";
}

export function weekKey(d = new Date()) {
  const date = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const day = date.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  date.setDate(date.getDate() + diff);
  return todayKey(date);
}

export function endOfWeekKey(day: string) {
  const date = parseDay(day, "12:00");
  const dow = date.getDay();
  const add = dow === 0 ? 0 : 7 - dow;
  date.setDate(date.getDate() + add);
  return todayKey(date);
}

export function mergeQuotes(saved: Quote[] | undefined): Quote[] {
  const byId = new Map((saved ?? []).map((q) => [q.id, q]));
  return QUOTE_CATALOG.map((q) => {
    const prev = byId.get(q.id);
    if (!prev) return q;
    return { ...q, unlocked: prev.unlocked || q.cost === 0 };
  });
}

export function pickQuote(quotes: Quote[], id: string) {
  return quotes.find((q) => q.id === id && q.unlocked) ?? quotes.find((q) => q.unlocked) ?? quotes[0];
}

export function goalProgress(goalId: string, tasks: Task[]) {
  const linked = tasks.filter((t) => t.goalId === goalId);
  if (!linked.length) return 0;
  return Math.round((linked.filter((t) => t.done).length / linked.length) * 100);
}

export function focusMinutes(log: FocusEntry[], taskId?: string) {
  return log
    .filter((entry) => (taskId ? entry.taskId === taskId : true))
    .reduce((sum, entry) => sum + entry.minutes, 0);
}

export function remindAt(task: Pick<Task, "due" | "dueTime" | "remind">) {
  if (!task.due || task.remind === "off") return null;
  if (task.remind === "morning") return parseDay(task.due, "09:00");
  const due = parseDay(task.due, task.dueTime || "09:00");
  const mins = task.remind === "m60" ? 60 : task.remind === "m180" ? 180 : task.remind === "d1" ? 1440 : 0;
  return new Date(due.getTime() - mins * 60_000);
}

export function inQuiet(now: Date, start: string, end: string) {
  const mins = now.getHours() * 60 + now.getMinutes();
  const [sh, sm] = start.split(":").map(Number);
  const [eh, em] = end.split(":").map(Number);
  const s = (sh || 0) * 60 + (sm || 0);
  const e = (eh || 0) * 60 + (em || 0);
  if (s === e) return false;
  if (s < e) return mins >= s && mins < e;
  return mins >= s || mins < e;
}

export function completionStreak(events: AnalyticsEvent[], today: string) {
  const days = new Set(events.filter((event) => event.type === "task_completed").map((event) => event.day));
  const cursor = parseDay(today, "12:00");
  if (!days.has(todayKey(cursor))) cursor.setDate(cursor.getDate() - 1);
  let count = 0;
  while (days.has(todayKey(cursor))) {
    count += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return count;
}

export function elapsedMs(active: ActiveFocus, now = Date.now()) {
  return active.accumulatedMs + (active.running ? Math.max(0, now - active.startedAt) : 0);
}

export function priorityWeight(priority: Priority) {
  return { critical: 0, high: 1, medium: 2, low: 3, someday: 4 }[priority];
}

export function buildMonth(year: number, month: number) {
  const first = new Date(year, month, 1);
  const pad = (first.getDay() + 6) % 7;
  const days = new Date(year, month + 1, 0).getDate();
  const cells: (string | null)[] = [];
  for (let i = 0; i < pad; i += 1) cells.push(null);
  for (let d = 1; d <= days; d += 1) cells.push(todayKey(new Date(year, month, d)));
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}

export type PlannerShape = {
  goals: Goal[];
  tasks: Task[];
  focusLog: FocusEntry[];
  scheduled: ScheduledFocus[];
  wishes: Wish[];
  quotes: Quote[];
  points: number;
  events: AnalyticsEvent[];
  water: Record<string, number>;
  weekNotes: Record<string, WeekNote>;
  settings: Settings;
  active: ActiveFocus | null;
  fired: string[];
};

export function blankTask(partial: Partial<Task> & Pick<Task, "title">): Task {
  return {
    id: uid(),
    title: partial.title.trim(),
    notes: partial.notes?.trim() ?? "",
    goalId: partial.goalId,
    priority: partial.priority ?? "medium",
    due: partial.due || undefined,
    dueTime: partial.dueTime || undefined,
    progress: 0,
    done: false,
    createdAt: new Date().toISOString(),
    pointsAwarded: 0,
    remind: partial.remind ?? "morning",
    anchor: false,
    energy: partial.energy ?? "any",
  };
}
