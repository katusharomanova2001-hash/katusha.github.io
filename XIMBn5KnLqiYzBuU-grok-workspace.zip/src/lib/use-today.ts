import { useEffect, useState } from "react";
import { todayKey } from "@/lib/model";

export function useTodayKey() {
  const [day, setDay] = useState<string | null>(null);
  useEffect(() => {
    const update = () => setDay(todayKey());
    update();
    const id = window.setInterval(update, 60_000);
    return () => window.clearInterval(id);
  }, []);
  return day;
}
