import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { TasksView } from "@/components/views/tasks";

export const Route = createFileRoute("/tasks")({
  component: function TasksPage() {
    return (
      <AppShell>
        <TasksView />
      </AppShell>
    );
  },
});
