import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { TodayView } from "@/components/views/today";

export const Route = createFileRoute("/")({
  component: function HomePage() {
    return (
      <AppShell>
        <TodayView />
      </AppShell>
    );
  },
});
