import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { WishesView } from "@/components/views/wishes";

export const Route = createFileRoute("/wishes")({
  component: function WishesPage() {
    return (
      <AppShell>
        <WishesView />
      </AppShell>
    );
  },
});
