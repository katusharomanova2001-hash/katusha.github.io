import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { InsightsView } from "@/components/views/insights";

export const Route = createFileRoute("/insights")({
  component: function InsightsPage() {
    return (
      <AppShell>
        <InsightsView />
      </AppShell>
    );
  },
});
