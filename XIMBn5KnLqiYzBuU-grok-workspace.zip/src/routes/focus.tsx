import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { FocusView } from "@/components/views/focus";

export const Route = createFileRoute("/focus")({
  component: function FocusPage() {
    return (
      <AppShell>
        <FocusView />
      </AppShell>
    );
  },
});
