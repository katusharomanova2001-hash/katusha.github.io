import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { QuotesView } from "@/components/views/quotes";

export const Route = createFileRoute("/quotes")({
  component: function QuotesPage() {
    return (
      <AppShell>
        <QuotesView />
      </AppShell>
    );
  },
});
