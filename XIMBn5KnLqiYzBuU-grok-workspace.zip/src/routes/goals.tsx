import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { GoalsView } from "@/components/views/goals";

export const Route = createFileRoute("/goals")({
  component: function GoalsPage() {
    return (
      <AppShell>
        <GoalsView />
      </AppShell>
    );
  },
});
