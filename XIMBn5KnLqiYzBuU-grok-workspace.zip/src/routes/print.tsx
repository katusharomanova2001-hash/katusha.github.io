import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { PrintView } from "@/components/views/print-view";

export const Route = createFileRoute("/print")({
  component: function PrintPage() {
    return (
      <AppShell>
        <PrintView />
      </AppShell>
    );
  },
});
