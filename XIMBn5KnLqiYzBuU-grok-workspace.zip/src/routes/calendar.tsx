import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { CalendarView } from "@/components/views/calendar";

export const Route = createFileRoute("/calendar")({
  component: function CalendarPage() {
    return (
      <AppShell>
        <CalendarView />
      </AppShell>
    );
  },
});
