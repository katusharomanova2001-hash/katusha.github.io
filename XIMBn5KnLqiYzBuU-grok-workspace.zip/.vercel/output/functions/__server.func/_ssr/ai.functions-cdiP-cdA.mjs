import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai.functions-cdiP-cdA.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var PRIORITIES = /* @__PURE__ */ new Set([
	"critical",
	"high",
	"medium",
	"low",
	"someday"
]);
var lastCall = 0;
function asPriority(value) {
	const priority = {
		critical: "critical",
		high: "high",
		medium: "medium",
		low: "low",
		someday: "someday",
		срочно: "critical",
		важно: "high",
		нужно: "medium",
		позже: "low",
		"когда-нибудь": "someday"
	}[String(value ?? "").trim().toLowerCase()];
	return priority && PRIORITIES.has(priority) ? priority : "medium";
}
function asKind(value) {
	const raw = String(value ?? "").toLowerCase();
	if (raw.includes("dream") || raw.includes("мечт")) return "dream";
	return "goal";
}
function parsePlan(text, fallbackTitle) {
	const trimmed = text.trim();
	const raw = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/)?.[1] ?? trimmed;
	let data;
	try {
		data = JSON.parse(raw);
	} catch {
		return null;
	}
	if (!data || typeof data !== "object") return null;
	const body = data;
	const steps = (Array.isArray(body.steps) ? body.steps : []).map((step) => {
		const item = step && typeof step === "object" ? step : {};
		return {
			title: String(item.title ?? "").trim(),
			priority: asPriority(item.priority),
			note: String(item.note ?? "").trim()
		};
	}).filter((step) => step.title).slice(0, 8);
	if (!steps.length) return null;
	const title = String(body.title ?? "").trim() || fallbackTitle;
	const date = String(body.targetDate ?? "");
	return {
		title: title.slice(0, 120),
		summary: String(body.summary ?? "").trim().slice(0, 400),
		kind: asKind(body.kind),
		targetDate: /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : void 0,
		steps
	};
}
async function complete(apiKey, description, jsonMode) {
	return fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			temperature: .4,
			max_tokens: 900,
			...jsonMode ? { response_format: { type: "json_object" } } : {},
			messages: [{
				role: "system",
				content: "Ты помощник по личному планированию. Верни только JSON без пояснений: {\"title\":\"короткое название\",\"summary\":\"зачем это, одно предложение\",\"kind\":\"goal или dream\",\"targetDate\":\"YYYY-MM-DD или null\",\"steps\":[{\"title\":\"конкретное действие\",\"priority\":\"critical|high|medium|low|someday\",\"note\":\"почему такой приоритет, до 12 слов\"}]}. 4–7 шагов, от ближайшего к дальнему. Шаги — действия, не лозунги. critical только если без этого всё стоит. kind=dream для образа жизни без жёсткого срока, иначе goal. Язык пользователя. Без emoji."
			}, {
				role: "user",
				content: description
			}]
		})
	});
}
var planGoal_createServerFn_handler = createServerRpc({
	id: "bad5b254f0a0ab0de6329e51e3aaf1ef57f83857fa122812f265b55d9935c0d7",
	name: "planGoal",
	filename: "src/lib/ai.functions.ts"
}, (opts) => planGoal.__executeServer(opts));
var planGoal = createServerFn({ method: "POST" }).validator((input) => {
	return { description: (input && typeof input === "object" && "description" in input ? String(input.description ?? "") : "").trim().slice(0, 2e3) };
}).handler(planGoal_createServerFn_handler, async ({ data }) => {
	if (data.description.length < 8) return {
		ok: false,
		error: "Опишите цель чуть подробнее — хотя бы пару фраз."
	};
	const now = Date.now();
	if (now - lastCall < 8e3) return {
		ok: false,
		error: "Подождите пару секунд и попробуйте ещё раз."
	};
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "Сейчас модель недоступна. Цель можно записать вручную."
	};
	lastCall = now;
	try {
		let response = await complete(apiKey, data.description, true);
		if (!response.ok && (response.status === 400 || response.status === 422)) response = await complete(apiKey, data.description, false);
		if (!response.ok) return {
			ok: false,
			error: "Модель не ответила. Попробуйте ещё раз чуть позже."
		};
		const plan = parsePlan((await response.json()).choices?.[0]?.message?.content ?? "", data.description.slice(0, 80));
		if (!plan) return {
			ok: false,
			error: "Не удалось разобрать шаги. Попробуйте описать цель иначе."
		};
		return {
			ok: true,
			plan
		};
	} catch {
		return {
			ok: false,
			error: "Не вышло связаться с моделью. Проверьте сеть и попробуйте ещё раз."
		};
	}
});
//#endregion
export { planGoal_createServerFn_handler };
