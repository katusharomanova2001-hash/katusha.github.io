import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as useTodayKey, C as focusMinutes, O as todayKey, i as Card, k as usePlanner, m as PageHead, t as AppShell } from "./shell-mPTNwIV3.mjs";
import { n as parseISO, r as format, t as ru } from "../_libs/date-fns.mjs";
import { a as Bar, i as CartesianGrid, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights-Bu63Zx-A.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var LABELS = {
	goal_created: "Цель",
	task_created: "Задача",
	focus_started: "Фокус",
	task_completed: "Готово"
};
function InsightsView() {
	const events = usePlanner((state) => state.events);
	const focusLog = usePlanner((state) => state.focusLog);
	const day = useTodayKey();
	const chart = (0, import_react.useMemo)(() => {
		if (!day) return [];
		const start = parseDay(day);
		start.setDate(start.getDate() - 13);
		return Array.from({ length: 14 }, (_, index) => {
			const date = new Date(start);
			date.setDate(start.getDate() + index);
			const key = todayKey(date);
			const same = events.filter((event) => event.day === key);
			return {
				name: format(date, "d MMM", { locale: ru }),
				goals: same.filter((event) => event.type === "goal_created").length,
				tasks: same.filter((event) => event.type === "task_created").length,
				focus: same.filter((event) => event.type === "focus_started").length,
				done: same.filter((event) => event.type === "task_completed").length
			};
		});
	}, [day, events]);
	const totals = {
		goals: events.filter((event) => event.type === "goal_created").length,
		tasks: events.filter((event) => event.type === "task_created").length,
		focus: events.filter((event) => event.type === "focus_started").length,
		done: events.filter((event) => event.type === "task_completed").length
	};
	const byTask = /* @__PURE__ */ new Map();
	for (const entry of focusLog) byTask.set(entry.title, (byTask.get(entry.title) ?? 0) + entry.minutes);
	const top = [...byTask.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "Что уже произошло",
			title: "Обзор"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Целей создано",
					value: totals.goals
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Задач создано",
					value: totals.tasks
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Фокус-сессий",
					value: totals.focus
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Задач закрыто",
					value: totals.done
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl",
					children: "14 дней"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Создание целей и задач, старты фокуса и закрытые задачи."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 h-64 w-full min-w-0",
					children: chart.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted",
						children: "Считаю дни."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: chart,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
									vertical: false,
									stroke: "var(--color-line)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "name",
									tick: {
										fill: "var(--color-muted)",
										fontSize: 12
									},
									axisLine: false,
									tickLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									allowDecimals: false,
									width: 28,
									tick: {
										fill: "var(--color-muted)",
										fontSize: 12
									},
									axisLine: false,
									tickLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									cursor: { fill: "var(--color-surface-2)" },
									contentStyle: {
										background: "var(--color-surface)",
										border: "1px solid var(--color-line)",
										borderRadius: 12,
										color: "var(--color-ink)"
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "done",
									name: "Закрыто",
									fill: "var(--color-accent)",
									radius: [
										4,
										4,
										0,
										0
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "focus",
									name: "Фокус",
									fill: "var(--color-ink)",
									radius: [
										4,
										4,
										0,
										0
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "tasks",
									name: "Задачи",
									fill: "var(--color-muted)",
									radius: [
										4,
										4,
										0,
										0
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "goals",
									name: "Цели",
									fill: "var(--color-line)",
									radius: [
										4,
										4,
										0,
										0
									]
								})
							]
						})
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 grid gap-5 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl",
					children: "Куда ушло внимание"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						"Всего ",
						focusMinutes(focusLog),
						" мин фокуса."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 divide-y divide-line",
					children: [top.map(([name, minutes]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-baseline justify-between gap-3 py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-0 truncate",
							children: name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums text-muted",
							children: [minutes, " мин"]
						})]
					}, name)), top.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "py-2 text-sm text-muted",
						children: "Запустите первую сессию, и здесь появится отчёт."
					}) : null]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl",
				children: "Лента"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-4 divide-y divide-line",
				children: [events.slice(0, 8).map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "py-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted",
						children: [LABELS[event.type], " · "]
					}), event.label] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted",
						children: format(parseISO(event.at), "d MMMM, HH:mm", { locale: ru })
					})]
				}, event.id)), events.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "py-2 text-sm text-muted",
					children: "Пока нечего считать. Создайте цель или задачу."
				}) : null]
			})] })]
		})
	] });
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 font-display text-4xl tabular-nums",
		children: value
	})] });
}
function parseDay(day) {
	const [y, m, d] = day.split("-").map(Number);
	return new Date(y, (m || 1) - 1, d || 1);
}
var SplitComponent = function InsightsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsView, {}) });
};
//#endregion
export { SplitComponent as component };
