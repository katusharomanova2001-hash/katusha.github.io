import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, m as useRouterState, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Settings, c as ListChecks, h as Bell, i as Sun, l as Gift, m as CalendarDays, o as Quote, p as ChartColumn, r as Timer, s as Printer, t as X, u as Compass } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-mPTNwIV3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var POINT_VALUES = {
	critical: 30,
	high: 18,
	medium: 10,
	low: 5,
	someday: 3
};
var PRIORITY_LABEL = {
	critical: "Срочно",
	high: "Важно",
	medium: "Нужно",
	low: "Можно позже",
	someday: "Когда-нибудь"
};
var REMIND_LABEL = {
	off: "Без напоминания",
	at: "В момент срока",
	m60: "За час",
	m180: "За 3 часа",
	d1: "За день",
	morning: "Утром в день срока"
};
var ENERGY_LABEL = {
	any: "Когда угодно",
	morning: "Утро",
	day: "День",
	evening: "Вечер"
};
var QUOTE_CATALOG = [
	{
		id: "q1",
		cost: 0,
		unlocked: true,
		author: "Светлица",
		text: "Маленький шаг сегодня весит больше, чем идеальный план на потом."
	},
	{
		id: "q2",
		cost: 0,
		unlocked: true,
		author: "Светлица",
		text: "Внимание — самая честная валюта дня. Тратьте её на то, что правда ваше."
	},
	{
		id: "q3",
		cost: 0,
		unlocked: true,
		author: "Светлица",
		text: "Не всё сразу. Одна ясная задача уже двигает неделю."
	},
	{
		id: "q4",
		cost: 20,
		unlocked: false,
		author: "Светлица",
		text: "Мечта без ближайшего шага — просто красивая мысль. Шаг можно сделать за двадцать минут."
	},
	{
		id: "q5",
		cost: 20,
		unlocked: false,
		author: "Светлица",
		text: "Отдых тоже входит в план. Усталость плохо хранит обещания."
	},
	{
		id: "q6",
		cost: 35,
		unlocked: false,
		author: "Светлица",
		text: "Если задача страшная, уменьшите её до того, что можно начать с чашкой чая рядом."
	},
	{
		id: "q7",
		cost: 35,
		unlocked: false,
		author: "Светлица",
		text: "Вы не опаздываете к своей жизни. Вы как раз в том дне, который есть."
	},
	{
		id: "q8",
		cost: 50,
		unlocked: false,
		author: "Светлица",
		text: "Сделанное молча тоже считается. Не каждая победа должна быть громкой."
	},
	{
		id: "q9",
		cost: 50,
		unlocked: false,
		author: "Светлица",
		text: "Список желаний — не витрина вины. Это направление, куда смотреть, когда есть место."
	},
	{
		id: "q10",
		cost: 70,
		unlocked: false,
		author: "Светлица",
		text: "Граница тоже цель: сказать нет лишнему, чтобы сказать да своему."
	},
	{
		id: "q11",
		cost: 70,
		unlocked: false,
		author: "Светлица",
		text: "Вода, сон и один честный час фокуса чинят больше, чем ещё десять вкладок."
	},
	{
		id: "q12",
		cost: 90,
		unlocked: false,
		author: "Светлица",
		text: "Пусть неделя будет короткой историей: что сдвинулось, что отпустить, чему отдать утро."
	}
];
var DEFAULT_SETTINGS = {
	name: "",
	waterGoal: 8,
	waterEveryMin: 90,
	waterOn: true,
	notify: false,
	quietStart: "22:00",
	quietEnd: "08:00",
	activeQuoteId: "q1"
};
function uid() {
	if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
	return `id-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}
function todayKey(d = /* @__PURE__ */ new Date()) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function parseDay(isoDate, time = "09:00") {
	const [y, m, d] = isoDate.split("-").map(Number);
	const [hh, mm] = time.split(":").map(Number);
	return new Date(y, (m || 1) - 1, d || 1, hh || 0, mm || 0, 0, 0);
}
function greet(d) {
	const h = d.getHours();
	if (h < 5) return "Доброй ночи";
	if (h < 12) return "Доброе утро";
	if (h < 18) return "Добрый день";
	return "Добрый вечер";
}
function weekKey(d = /* @__PURE__ */ new Date()) {
	const date = new Date(d.getFullYear(), d.getMonth(), d.getDate());
	const day = date.getDay();
	const diff = day === 0 ? -6 : 1 - day;
	date.setDate(date.getDate() + diff);
	return todayKey(date);
}
function endOfWeekKey(day) {
	const date = parseDay(day, "12:00");
	const dow = date.getDay();
	const add = dow === 0 ? 0 : 7 - dow;
	date.setDate(date.getDate() + add);
	return todayKey(date);
}
function mergeQuotes(saved) {
	const byId = new Map((saved ?? []).map((q) => [q.id, q]));
	return QUOTE_CATALOG.map((q) => {
		const prev = byId.get(q.id);
		if (!prev) return q;
		return {
			...q,
			unlocked: prev.unlocked || q.cost === 0
		};
	});
}
function pickQuote(quotes, id) {
	return quotes.find((q) => q.id === id && q.unlocked) ?? quotes.find((q) => q.unlocked) ?? quotes[0];
}
function goalProgress(goalId, tasks) {
	const linked = tasks.filter((t) => t.goalId === goalId);
	if (!linked.length) return 0;
	return Math.round(linked.filter((t) => t.done).length / linked.length * 100);
}
function focusMinutes(log, taskId) {
	return log.filter((entry) => taskId ? entry.taskId === taskId : true).reduce((sum, entry) => sum + entry.minutes, 0);
}
function remindAt(task) {
	if (!task.due || task.remind === "off") return null;
	if (task.remind === "morning") return parseDay(task.due, "09:00");
	const due = parseDay(task.due, task.dueTime || "09:00");
	const mins = task.remind === "m60" ? 60 : task.remind === "m180" ? 180 : task.remind === "d1" ? 1440 : 0;
	return /* @__PURE__ */ new Date(due.getTime() - mins * 6e4);
}
function inQuiet(now, start, end) {
	const mins = now.getHours() * 60 + now.getMinutes();
	const [sh, sm] = start.split(":").map(Number);
	const [eh, em] = end.split(":").map(Number);
	const s = (sh || 0) * 60 + (sm || 0);
	const e = (eh || 0) * 60 + (em || 0);
	if (s === e) return false;
	if (s < e) return mins >= s && mins < e;
	return mins >= s || mins < e;
}
function completionStreak(events, today) {
	const days = new Set(events.filter((event) => event.type === "task_completed").map((event) => event.day));
	const cursor = parseDay(today, "12:00");
	if (!days.has(todayKey(cursor))) cursor.setDate(cursor.getDate() - 1);
	let count = 0;
	while (days.has(todayKey(cursor))) {
		count += 1;
		cursor.setDate(cursor.getDate() - 1);
	}
	return count;
}
function elapsedMs(active, now = Date.now()) {
	return active.accumulatedMs + (active.running ? Math.max(0, now - active.startedAt) : 0);
}
function priorityWeight(priority) {
	return {
		critical: 0,
		high: 1,
		medium: 2,
		low: 3,
		someday: 4
	}[priority];
}
function buildMonth(year, month) {
	const pad = (new Date(year, month, 1).getDay() + 6) % 7;
	const days = new Date(year, month + 1, 0).getDate();
	const cells = [];
	for (let i = 0; i < pad; i += 1) cells.push(null);
	for (let d = 1; d <= days; d += 1) cells.push(todayKey(new Date(year, month, d)));
	while (cells.length % 7 !== 0) cells.push(null);
	return cells;
}
function blankTask(partial) {
	return {
		id: uid(),
		title: partial.title.trim(),
		notes: partial.notes?.trim() ?? "",
		goalId: partial.goalId,
		priority: partial.priority ?? "medium",
		due: partial.due || void 0,
		dueTime: partial.dueTime || void 0,
		progress: 0,
		done: false,
		createdAt: (/* @__PURE__ */ new Date()).toISOString(),
		pointsAwarded: 0,
		remind: partial.remind ?? "morning",
		anchor: false,
		energy: partial.energy ?? "any"
	};
}
var field = "min-h-11 w-full rounded-xl border border-line bg-surface px-3 text-base text-ink outline-none placeholder:text-muted";
function Field(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...props,
		className: cn(field, props.className)
	});
}
function Area(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		...props,
		className: cn(field, "min-h-28 py-3", props.className)
	});
}
function Select(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		...props,
		className: cn(field, props.className)
	});
}
function Button({ variant = "primary", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn("inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-semibold transition-opacity disabled:cursor-not-allowed disabled:opacity-40", variant === "primary" && "bg-accent text-on-accent", variant === "quiet" && "bg-surface-2 text-ink", variant === "ghost" && "bg-transparent text-ink", variant === "danger" && "bg-transparent text-accent", className),
		...props
	});
}
function IconButton({ label, children, className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		className: cn("inline-flex size-11 items-center justify-center rounded-xl text-ink hover:bg-surface-2", className),
		...props,
		children
	});
}
function Modal({ open, title, onClose, children }) {
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (event) => {
			if (event.key === "Escape") onClose();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open, onClose]);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Закрыть",
			className: "absolute inset-0 bg-ink/40",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "dialog-title",
			className: "relative z-10 max-h-full w-full overflow-y-auto rounded-t-2xl border border-line bg-surface p-5 shadow-card sm:max-w-xl sm:rounded-2xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "dialog-title",
					className: "font-display text-3xl leading-tight text-ink",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
					label: "Закрыть",
					onClick: onClose,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), children]
		})]
	});
}
function Card({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("rounded-2xl border border-line bg-surface p-4 shadow-card md:p-5", className),
		children
	});
}
function PageHead({ kicker, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-6 flex flex-wrap items-end justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [kicker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: kicker
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl leading-tight text-ink md:text-5xl",
				children: title
			})]
		}), children]
	});
}
function Meter({ value, label }) {
	const safe = Math.max(0, Math.min(100, value));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-2 w-full overflow-hidden rounded-full bg-surface-2",
		role: "meter",
		"aria-valuenow": safe,
		"aria-valuemin": 0,
		"aria-valuemax": 100,
		"aria-label": label,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full rounded-full bg-accent",
			style: { width: `${safe}%` }
		})
	});
}
function PriorityMark({ priority }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("text-sm", priority === "critical" ? "font-semibold text-accent" : "text-muted"),
		children: PRIORITY_LABEL[priority]
	});
}
function Empty({ title, text, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-dashed border-line bg-surface px-5 py-10 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl text-ink",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-2 max-w-md text-muted",
				children: text
			}),
			action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 flex justify-center",
				children: action
			}) : null
		]
	});
}
function Label({ children, htmlFor }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		htmlFor,
		className: "mb-1 block text-sm text-muted",
		children
	});
}
function event(type, label) {
	const at = /* @__PURE__ */ new Date();
	return {
		id: uid(),
		type,
		at: at.toISOString(),
		day: todayKey(at),
		label
	};
}
function emptyWeek() {
	return {
		moved: "",
		drop: "",
		focus: ""
	};
}
function mergeState(persisted, current) {
	if (!persisted || typeof persisted !== "object") return current;
	const saved = persisted;
	const settings = {
		...DEFAULT_SETTINGS,
		...saved.settings ?? {}
	};
	const quotes = mergeQuotes(saved.quotes);
	if (!quotes.some((quote) => quote.id === settings.activeQuoteId && quote.unlocked)) settings.activeQuoteId = quotes.find((quote) => quote.unlocked)?.id ?? "q1";
	return {
		...current,
		goals: Array.isArray(saved.goals) ? saved.goals : [],
		tasks: Array.isArray(saved.tasks) ? saved.tasks : [],
		focusLog: Array.isArray(saved.focusLog) ? saved.focusLog : [],
		scheduled: Array.isArray(saved.scheduled) ? saved.scheduled : [],
		wishes: Array.isArray(saved.wishes) ? saved.wishes : [],
		events: Array.isArray(saved.events) ? saved.events : [],
		water: saved.water && typeof saved.water === "object" ? saved.water : {},
		weekNotes: saved.weekNotes && typeof saved.weekNotes === "object" ? saved.weekNotes : {},
		fired: Array.isArray(saved.fired) ? saved.fired : [],
		points: typeof saved.points === "number" ? saved.points : 0,
		active: saved.active ?? null,
		quotes,
		settings
	};
}
function memoryStorage() {
	const bag = /* @__PURE__ */ new Map();
	return {
		getItem: (name) => bag.get(name) ?? null,
		setItem: (name, value) => {
			bag.set(name, value);
		},
		removeItem: (name) => {
			bag.delete(name);
		}
	};
}
var usePlanner = create()(persist((set, get) => ({
	goals: [],
	tasks: [],
	focusLog: [],
	scheduled: [],
	wishes: [],
	quotes: mergeQuotes(void 0),
	points: 0,
	events: [],
	water: {},
	weekNotes: {},
	settings: DEFAULT_SETTINGS,
	active: null,
	fired: [],
	setSettings: (patch) => set((state) => ({ settings: {
		...state.settings,
		...patch
	} })),
	addGoal: (input) => {
		const title = input.title.trim();
		if (!title) return null;
		const goal = {
			id: uid(),
			title,
			description: input.description.trim(),
			kind: input.kind,
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			targetDate: input.targetDate || void 0
		};
		set((state) => ({
			goals: [goal, ...state.goals],
			events: [event("goal_created", goal.title), ...state.events].slice(0, 400)
		}));
		return goal.id;
	},
	addPlannedGoal: (input) => {
		const title = input.title.trim();
		if (!title) return;
		const goal = {
			id: uid(),
			title,
			description: input.description.trim(),
			kind: input.kind,
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			targetDate: input.targetDate || void 0
		};
		const tasks = input.steps.filter((step) => step.title.trim()).map((step) => blankTask({
			title: step.title,
			notes: step.note,
			goalId: goal.id,
			priority: step.priority,
			remind: "morning"
		}));
		const taskEvents = tasks.map((task) => event("task_created", task.title));
		set((state) => ({
			goals: [goal, ...state.goals],
			tasks: [...tasks, ...state.tasks],
			events: [
				event("goal_created", goal.title),
				...taskEvents,
				...state.events
			].slice(0, 400)
		}));
	},
	deleteGoal: (id) => set((state) => ({
		goals: state.goals.filter((goal) => goal.id !== id),
		tasks: state.tasks.map((task) => task.goalId === id ? {
			...task,
			goalId: void 0
		} : task)
	})),
	addTask: (input) => {
		const task = blankTask(input);
		if (!task.title) return;
		set((state) => ({
			tasks: [task, ...state.tasks],
			events: [event("task_created", task.title), ...state.events].slice(0, 400)
		}));
	},
	updateTask: (id, patch) => set((state) => ({ tasks: state.tasks.map((task) => task.id === id ? {
		...task,
		...patch,
		id: task.id
	} : task) })),
	toggleTask: (id) => {
		let delta = 0;
		set((state) => {
			const task = state.tasks.find((item) => item.id === id);
			if (!task) return state;
			if (!task.done) {
				delta = POINT_VALUES[task.priority];
				const completed = event("task_completed", task.title);
				return {
					points: state.points + delta,
					tasks: state.tasks.map((item) => item.id === id ? {
						...item,
						done: true,
						progress: 100,
						completedAt: completed.at,
						completedEventId: completed.id,
						pointsAwarded: delta,
						anchor: false
					} : item),
					events: [completed, ...state.events].slice(0, 400)
				};
			}
			delta = -task.pointsAwarded;
			return {
				points: Math.max(0, state.points - task.pointsAwarded),
				tasks: state.tasks.map((item) => item.id === id ? {
					...item,
					done: false,
					completedAt: void 0,
					completedEventId: void 0,
					pointsAwarded: 0
				} : item),
				events: state.events.filter((item) => item.id !== task.completedEventId)
			};
		});
		return delta;
	},
	setProgress: (id, progress) => set((state) => ({ tasks: state.tasks.map((task) => task.id === id ? {
		...task,
		progress: Math.max(0, Math.min(100, Math.round(progress)))
	} : task) })),
	setAnchor: (id) => set((state) => ({ tasks: state.tasks.map((task) => ({
		...task,
		anchor: task.id === id ? !task.anchor : false
	})) })),
	deleteTask: (id) => set((state) => ({ tasks: state.tasks.filter((task) => task.id !== id) })),
	addWish: (input) => {
		const title = input.title.trim();
		if (!title) return;
		const wish = {
			id: uid(),
			title,
			url: input.url.trim(),
			note: input.note.trim(),
			price: input.price.trim(),
			image: input.image,
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			bought: false
		};
		set((state) => ({ wishes: [wish, ...state.wishes] }));
	},
	updateWish: (id, patch) => set((state) => ({ wishes: state.wishes.map((wish) => wish.id === id ? {
		...wish,
		...patch
	} : wish) })),
	deleteWish: (id) => set((state) => ({ wishes: state.wishes.filter((wish) => wish.id !== id) })),
	unlockQuote: (id) => {
		const state = get();
		const quote = state.quotes.find((item) => item.id === id);
		if (!quote) return "missing";
		if (quote.unlocked) return "already";
		if (state.points < quote.cost) return "poor";
		set({
			points: state.points - quote.cost,
			quotes: state.quotes.map((item) => item.id === id ? {
				...item,
				unlocked: true
			} : item),
			settings: {
				...state.settings,
				activeQuoteId: id
			}
		});
		return "ok";
	},
	setActiveQuote: (id) => {
		if (!get().quotes.find((item) => item.id === id && item.unlocked)) return;
		set((state) => ({ settings: {
			...state.settings,
			activeQuoteId: id
		} }));
	},
	addWater: (day, delta) => set((state) => {
		const next = Math.max(0, (state.water[day] ?? 0) + delta);
		return { water: {
			...state.water,
			[day]: next
		} };
	}),
	setWeekNote: (key, patch) => set((state) => ({ weekNotes: {
		...state.weekNotes,
		[key]: {
			...emptyWeek(),
			...state.weekNotes[key],
			...patch
		}
	} })),
	startFocus: (input) => {
		if (get().active) return false;
		const title = input.title.trim() || "Фокус";
		const active = {
			title,
			taskId: input.taskId,
			plannedMinutes: Math.max(1, input.plannedMinutes),
			startedAt: Date.now(),
			accumulatedMs: 0,
			running: true,
			scheduleId: input.scheduleId
		};
		set((state) => ({
			active,
			events: [event("focus_started", title), ...state.events].slice(0, 400)
		}));
		return true;
	},
	pauseFocus: () => {
		const active = get().active;
		if (!active?.running) return;
		set({ active: {
			...active,
			running: false,
			accumulatedMs: elapsedMs(active)
		} });
	},
	resumeFocus: () => {
		const active = get().active;
		if (!active || active.running) return;
		set({ active: {
			...active,
			running: true,
			startedAt: Date.now()
		} });
	},
	finishFocus: () => {
		const active = get().active;
		if (!active) return 0;
		const minutes = Math.round(elapsedMs(active) / 6e4);
		const at = /* @__PURE__ */ new Date();
		set((state) => {
			return {
				active: null,
				focusLog: minutes >= 1 ? [{
					id: uid(),
					taskId: active.taskId,
					title: active.title,
					minutes,
					at: at.toISOString(),
					day: todayKey(at)
				}, ...state.focusLog].slice(0, 400) : state.focusLog,
				scheduled: active.scheduleId ? state.scheduled.map((item) => item.id === active.scheduleId ? {
					...item,
					done: true
				} : item) : state.scheduled
			};
		});
		return minutes;
	},
	discardFocus: () => set({ active: null }),
	scheduleFocus: (input) => {
		const title = input.title.trim();
		if (!title || !input.start) return;
		const item = {
			id: uid(),
			title,
			taskId: input.taskId,
			start: input.start,
			minutes: Math.max(1, input.minutes),
			remindMinutes: input.remindMinutes,
			done: false
		};
		set((state) => ({ scheduled: [...state.scheduled, item] }));
	},
	deleteScheduled: (id) => set((state) => ({ scheduled: state.scheduled.filter((item) => item.id !== id) })),
	markFired: (key) => {
		if (get().fired.includes(key)) return false;
		set((state) => ({ fired: [...state.fired, key].slice(-300) }));
		return true;
	},
	importSnapshot: (raw) => {
		if (!raw || typeof raw !== "object") return false;
		const body = raw;
		if (!Array.isArray(body.tasks) && !Array.isArray(body.goals) && !Array.isArray(body.wishes)) return false;
		set((state) => mergeState(raw, state));
		return true;
	}
}), {
	name: "svetlitsa-v1",
	skipHydration: true,
	storage: createJSONStorage(() => typeof window === "undefined" ? memoryStorage() : window.localStorage),
	partialize: (state) => ({
		goals: state.goals,
		tasks: state.tasks,
		focusLog: state.focusLog,
		scheduled: state.scheduled,
		wishes: state.wishes,
		quotes: state.quotes,
		points: state.points,
		events: state.events,
		water: state.water,
		weekNotes: state.weekNotes,
		settings: state.settings,
		active: state.active,
		fired: state.fired
	}),
	merge: (persisted, current) => mergeState(persisted, current)
}));
function SettingsDialog({ open, onClose }) {
	const settings = usePlanner((state) => state.settings);
	const setSettings = usePlanner((state) => state.setSettings);
	const importSnapshot = usePlanner((state) => state.importSnapshot);
	const fileRef = (0, import_react.useRef)(null);
	const [pending, setPending] = (0, import_react.useState)(null);
	function exportBackup() {
		const state = usePlanner.getState();
		const payload = {
			version: 1,
			goals: state.goals,
			tasks: state.tasks,
			focusLog: state.focusLog,
			scheduled: state.scheduled,
			wishes: state.wishes,
			quotes: state.quotes,
			points: state.points,
			events: state.events,
			water: state.water,
			weekNotes: state.weekNotes,
			settings: state.settings,
			active: state.active
		};
		const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = "svetlitsa-backup.json";
		link.click();
		URL.revokeObjectURL(url);
		toast("Копия скачана");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		title: "Настройки",
		onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "name",
					children: "Как к вам обращаться"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "name",
					value: settings.name,
					maxLength: 40,
					placeholder: "Имя",
					onChange: (event) => setSettings({ name: event.target.value })
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "water-goal",
						children: "Стаканов воды в день"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						id: "water-goal",
						type: "number",
						min: 1,
						max: 20,
						value: settings.waterGoal,
						onChange: (event) => setSettings({ waterGoal: clamp(Number(event.target.value), 1, 20) })
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "water-every",
						children: "Напоминать о воде"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						id: "water-every",
						value: String(settings.waterEveryMin),
						onChange: (event) => setSettings({ waterEveryMin: Number(event.target.value) }),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "45",
								children: "каждые 45 минут"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "60",
								children: "каждый час"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "90",
								children: "каждые полтора часа"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "120",
								children: "каждые 2 часа"
							})
						]
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex min-h-11 items-center justify-between gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Напоминания о воде" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						className: "size-5 accent-accent",
						checked: settings.waterOn,
						onChange: (event) => setSettings({ waterOn: event.target.checked })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "quiet-start",
						children: "Тишина с"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						id: "quiet-start",
						type: "time",
						value: settings.quietStart,
						onChange: (event) => setSettings({ quietStart: event.target.value })
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "quiet-end",
						children: "до"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						id: "quiet-end",
						type: "time",
						value: settings.quietEnd,
						onChange: (event) => setSettings({ quietEnd: event.target.value })
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-xl bg-surface-2 p-3 text-sm text-muted",
					children: "Напоминания о сроках, фокусе и воде приходят, пока Светлица открыта. Если вкладка закрыта, браузер не даст будильнику сработать. Уведомления поверх других окон можно разрешить отдельно."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "quiet",
					onClick: async () => {
						if (!("Notification" in window)) {
							toast("Этот браузер не показывает уведомления");
							return;
						}
						const result = await Notification.requestPermission();
						setSettings({ notify: result === "granted" });
						toast(result === "granted" ? "Уведомления включены" : "Уведомления не разрешены");
					},
					children: settings.notify ? "Уведомления браузера включены" : "Разрешить уведомления браузера"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-xl border border-line p-3 text-sm text-muted",
					children: "Записи живут только в этом браузере. Общий аккаунт не нужен, отдельного срока у страницы нет. Если очистить данные сайта или открыть другой браузер, списки пропадут — скачайте копию."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							onClick: exportBackup,
							children: "Скачать копию"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => fileRef.current?.click(),
							children: "Выбрать файл копии"
						}),
						pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								const ok = importSnapshot(pending);
								setPending(null);
								toast(ok ? "Копия восстановлена" : "Этот файл не похож на копию Светлицы");
							},
							children: "Заменить текущие записи"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: fileRef,
							type: "file",
							accept: "application/json",
							className: "hidden",
							onChange: async (event) => {
								const file = event.target.files?.[0];
								event.target.value = "";
								if (!file) return;
								try {
									setPending(JSON.parse(await file.text()));
									toast("Файл прочитан. Нажмите «Заменить текущие записи», если это нужная копия.");
								} catch {
									toast("Не удалось прочитать файл");
								}
							}
						})
					]
				})
			]
		})
	});
}
function clamp(value, min, max) {
	if (Number.isNaN(value)) return min;
	return Math.max(min, Math.min(max, value));
}
var openedAt = Date.now();
function Reminders() {
	(0, import_react.useEffect)(() => {
		const tick = () => {
			const state = usePlanner.getState();
			const now = /* @__PURE__ */ new Date();
			if (inQuiet(now, state.settings.quietStart, state.settings.quietEnd)) return;
			for (const task of state.tasks) {
				if (task.done) continue;
				const at = remindAt(task);
				if (!at) continue;
				const key = `task:${task.id}:${task.due}:${task.dueTime ?? ""}:${task.remind}`;
				if (now.getTime() < at.getTime() || now.getTime() > at.getTime() + 432e5) continue;
				if (!state.markFired(key)) continue;
				ping("Срок задачи", task.title);
			}
			for (const session of state.scheduled) {
				if (session.done) continue;
				const start = new Date(session.start).getTime();
				if (Number.isNaN(start)) continue;
				const at = start - session.remindMinutes * 6e4;
				const until = start + session.minutes * 6e4 + 9e5;
				if (now.getTime() < at || now.getTime() > until) continue;
				const key = `focus:${session.id}`;
				if (!usePlanner.getState().markFired(key)) continue;
				ping("Пора фокусироваться", `${session.title}, ${session.minutes} мин`);
			}
			const settings = usePlanner.getState().settings;
			if (!settings.waterOn) return;
			if (now.getTime() - openedAt < settings.waterEveryMin * 6e4) return;
			const day = todayKey(now);
			const drunk = usePlanner.getState().water[day] ?? 0;
			if (drunk >= settings.waterGoal) return;
			const key = `water:${day}:${Math.floor((now.getHours() * 60 + now.getMinutes()) / settings.waterEveryMin)}`;
			if (!usePlanner.getState().markFired(key)) return;
			ping("Вода", `Стакан воды. Сегодня ${drunk} из ${settings.waterGoal}.`);
		};
		const first = window.setTimeout(tick, 1500);
		const id = window.setInterval(tick, 3e4);
		return () => {
			window.clearTimeout(first);
			window.clearInterval(id);
		};
	}, []);
	return null;
}
function ping(title, body) {
	const notify = usePlanner.getState().settings.notify;
	toast(title, { description: body });
	if (notify && "Notification" in window && Notification.permission === "granted") new Notification(title, { body });
}
function useHydratePlanner() {
	const started = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (started.current) return;
		started.current = true;
		usePlanner.persist.rehydrate();
	}, []);
}
function useTodayKey() {
	const [day, setDay] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const update = () => setDay(todayKey());
		update();
		const id = window.setInterval(update, 6e4);
		return () => window.clearInterval(id);
	}, []);
	return day;
}
var NAV = [
	{
		to: "/",
		label: "Сегодня",
		icon: Sun
	},
	{
		to: "/goals",
		label: "Цели",
		icon: Compass
	},
	{
		to: "/tasks",
		label: "Задачи",
		icon: ListChecks
	},
	{
		to: "/focus",
		label: "Фокус",
		icon: Timer
	},
	{
		to: "/calendar",
		label: "Календарь",
		icon: CalendarDays
	},
	{
		to: "/wishes",
		label: "Желания",
		icon: Gift
	},
	{
		to: "/insights",
		label: "Обзор",
		icon: ChartColumn
	},
	{
		to: "/print",
		label: "Печать",
		icon: Printer
	},
	{
		to: "/quotes",
		label: "Цитаты",
		icon: Quote
	}
];
function AppShell({ children }) {
	useHydratePlanner();
	const path = useRouterState({ select: (state) => state.location.pathname });
	const points = usePlanner((state) => state.points);
	const tasks = usePlanner((state) => state.tasks);
	const day = useTodayKey();
	const [more, setMore] = (0, import_react.useState)(false);
	const [settings, setSettings] = (0, import_react.useState)(false);
	const due = day ? tasks.filter((task) => !task.done && task.due && task.due <= day).length : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "no-print fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-line bg-surface px-4 py-6 md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "mb-8 block px-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-4xl leading-none text-ink",
							children: "Светлица"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "личная мастерская"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex flex-1 flex-col gap-1",
						children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
							to: item.to,
							label: item.label,
							icon: item.icon,
							path
						}, item.to))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/quotes",
						className: "mt-4 flex min-h-11 items-center justify-between rounded-xl bg-accent-soft px-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "Очки"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums font-semibold",
							children: points
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shell-main md:pl-60",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "no-print sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-line bg-bg/90 px-4 py-3 backdrop-blur md:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "font-display text-2xl leading-none md:hidden",
							children: "Светлица"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "hidden text-sm text-muted md:block",
							children: "Только у вас, в этом браузере"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [
								due > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/tasks",
									className: "inline-flex min-h-11 items-center gap-2 rounded-xl px-3 text-sm text-accent",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, {
											className: "size-4",
											"aria-hidden": true
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "tabular-nums",
											children: due
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "sr-only",
											children: "задач со сроком"
										})
									]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums px-2 text-sm font-semibold md:hidden",
									children: points
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
									label: "Настройки",
									onClick: () => setSettings(true),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-5" })
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "mx-auto w-full max-w-5xl px-4 py-6 pb-28 md:px-8 md:pb-16",
					children
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "no-print fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-5",
					children: [NAV.slice(0, 4).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
						to: item.to,
						label: item.label,
						icon: item.icon,
						path,
						compact: true
					}, item.to)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex min-h-16 flex-col items-center justify-center gap-1 text-xs text-muted",
						onClick: () => setMore(true),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold",
							children: "Ещё"
						})
					})]
				})
			}),
			more ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-40 md:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Закрыть меню",
					className: "absolute inset-0 bg-ink/40",
					onClick: () => setMore(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-0 bottom-0 rounded-t-2xl border border-line bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl",
							children: "Ещё"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
							label: "Закрыть",
							onClick: () => setMore(false),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-1",
						children: [NAV.slice(4).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
							to: item.to,
							label: item.label,
							icon: item.icon,
							path,
							onClick: () => setMore(false)
						}, item.to)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex min-h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium",
							onClick: () => {
								setMore(false);
								setSettings(true);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-5" }), "Настройки"]
						})]
					})]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsDialog, {
				open: settings,
				onClose: () => setSettings(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reminders, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "top-center",
				toastOptions: { style: {
					background: "var(--color-surface)",
					color: "var(--color-ink)",
					border: "1px solid var(--color-line)"
				} }
			})
		]
	});
}
function NavLink({ to, label, icon: Icon, path, compact = false, onClick }) {
	const active = to === "/" ? path === "/" : path.startsWith(to);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		onClick,
		className: cn(compact ? "flex min-h-16 flex-col items-center justify-center gap-1 px-1 text-xs" : "flex min-h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium", active ? "text-accent" : "text-muted", !compact && active && "bg-accent-soft text-ink", !compact && !active && "hover:bg-surface-2 hover:text-ink"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: cn("size-5", active && compact && "text-accent"),
			strokeWidth: 1.75,
			"aria-hidden": true
		}), label]
	});
}
//#endregion
export { useTodayKey as A, focusMinutes as C, priorityWeight as D, pickQuote as E, todayKey as O, endOfWeekKey as S, greet as T, Select as _, ENERGY_LABEL as a, completionStreak as b, IconButton as c, Modal as d, POINT_VALUES as f, REMIND_LABEL as g, PriorityMark as h, Card as i, weekKey as j, usePlanner as k, Label as l, PageHead as m, Area as n, Empty as o, PRIORITY_LABEL as p, Button as r, Field as s, AppShell as t, Meter as u, buildMonth as v, goalProgress as w, elapsedMs as x, cn as y };
