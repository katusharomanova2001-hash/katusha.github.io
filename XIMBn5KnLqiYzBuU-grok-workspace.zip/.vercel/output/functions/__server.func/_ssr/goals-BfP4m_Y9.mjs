import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, K as isRedirect, S as useRouter, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { _ as Select, a as ENERGY_LABEL, d as Modal, i as Card, k as usePlanner, l as Label, m as PageHead, n as Area, o as Empty, p as PRIORITY_LABEL, r as Button, s as Field, t as AppShell, u as Meter, w as goalProgress } from "./shell-mPTNwIV3.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/goals-BfP4m_Y9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useServerFn(serverFn) {
	const router = useRouter();
	return import_react.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var planGoal = createServerFn({ method: "POST" }).validator((input) => {
	return { description: (input && typeof input === "object" && "description" in input ? String(input.description ?? "") : "").trim().slice(0, 2e3) };
}).handler(createSsrRpc("bad5b254f0a0ab0de6329e51e3aaf1ef57f83857fa122812f265b55d9935c0d7"));
var PRIORITIES = Object.keys(PRIORITY_LABEL);
function GoalsView() {
	const goals = usePlanner((state) => state.goals);
	const tasks = usePlanner((state) => state.tasks);
	const addGoal = usePlanner((state) => state.addGoal);
	const addTask = usePlanner((state) => state.addTask);
	const deleteGoal = usePlanner((state) => state.deleteGoal);
	const addPlannedGoal = usePlanner((state) => state.addPlannedGoal);
	const [kind, setKind] = (0, import_react.useState)("all");
	const [manual, setManual] = (0, import_react.useState)(false);
	const [aiOpen, setAiOpen] = (0, import_react.useState)(false);
	const visible = goals.filter((goal) => kind === "all" ? true : goal.kind === kind);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "Куда вы идёте",
			title: "Цели и мечты",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => setAiOpen(true),
					children: "Собрать шаги"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "quiet",
					onClick: () => setManual(true),
					children: "Записать вручную"
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-5 flex flex-wrap gap-2",
			children: [
				["all", "Все"],
				["goal", "Цели"],
				["dream", "Мечты"]
			].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setKind(id),
				className: kind === id ? "min-h-11 rounded-xl bg-accent-soft px-4 text-sm font-semibold text-ink" : "min-h-11 rounded-xl px-4 text-sm text-muted",
				children: label
			}, id))
		}),
		visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
			title: "Пока тихо",
			text: "Опишите цель своими словами — модель разложит её на шаги и предложит, что важнее. Или запишите сами, если уже знаете первый ход.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setAiOpen(true),
				children: "Собрать шаги"
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4",
			children: visible.map((goal) => {
				const linked = tasks.filter((task) => task.goalId === goal.id);
				const progress = goalProgress(goal.id, tasks);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: goal.kind === "dream" ? "Мечта" : "Цель"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-3xl leading-tight",
								children: goal.title
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "tabular-nums text-sm text-muted",
							children: [progress, "%"]
						})]
					}),
					goal.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted",
						children: goal.description
					}) : null,
					goal.targetDate ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: ["К ", goal.targetDate]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
							value: progress,
							label: `Прогресс: ${goal.title}`
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 divide-y divide-line",
						children: linked.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3 py-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: task.done ? "text-muted line-through" : "",
								children: task.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "shrink-0 text-muted",
								children: PRIORITY_LABEL[task.priority]
							})]
						}, task.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepForm, {
						goalId: goal.id,
						onAdd: addTask
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeleteButton, {
							label: "Удалить цель",
							onConfirm: () => {
								deleteGoal(goal.id);
								toast("Цель удалена, задачи остались в списке");
							}
						})
					})
				] }, goal.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ManualGoal, {
			open: manual,
			onClose: () => setManual(false),
			onSave: (input) => {
				const id = addGoal(input);
				if (!id) return;
				if (input.firstStep.trim()) addTask({
					title: input.firstStep,
					goalId: id,
					priority: "high",
					remind: "morning",
					energy: input.energy
				});
				setManual(false);
				toast("Записано");
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AiGoal, {
			open: aiOpen,
			onClose: () => setAiOpen(false),
			onSave: (plan) => {
				addPlannedGoal({
					title: plan.title,
					description: plan.summary,
					kind: plan.kind,
					targetDate: plan.targetDate,
					steps: plan.steps
				});
				setAiOpen(false);
				toast("Цель и шаги на месте");
			}
		})
	] });
}
function StepForm({ goalId, onAdd }) {
	const [title, setTitle] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "mt-4 flex flex-col gap-2 sm:flex-row",
		onSubmit: (event) => {
			event.preventDefault();
			if (!title.trim()) return;
			onAdd({
				title,
				goalId,
				priority: "medium"
			});
			setTitle("");
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			value: title,
			onChange: (event) => setTitle(event.target.value),
			placeholder: "Ещё один шаг",
			"aria-label": "Новый шаг"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "submit",
			variant: "quiet",
			children: "Добавить шаг"
		})]
	});
}
function DeleteButton({ label, onConfirm }) {
	const [sure, setSure] = (0, import_react.useState)(false);
	if (!sure) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "danger",
		onClick: () => setSure(true),
		children: label
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "danger",
			onClick: onConfirm,
			children: "Точно удалить"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			onClick: () => setSure(false),
			children: "Оставить"
		})]
	});
}
function ManualGoal({ open, onClose, onSave }) {
	const [title, setTitle] = (0, import_react.useState)("");
	const [description, setDescription] = (0, import_react.useState)("");
	const [kind, setKind] = (0, import_react.useState)("goal");
	const [targetDate, setTargetDate] = (0, import_react.useState)("");
	const [firstStep, setFirstStep] = (0, import_react.useState)("");
	const [energy, setEnergy] = (0, import_react.useState)("any");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		title: "Новая запись",
		onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-3",
			onSubmit: (event) => {
				event.preventDefault();
				onSave({
					title,
					description,
					kind,
					targetDate,
					firstStep,
					energy
				});
				setTitle("");
				setDescription("");
				setFirstStep("");
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: kind === "goal" ? "primary" : "quiet",
						onClick: () => setKind("goal"),
						children: "Цель"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: kind === "dream" ? "primary" : "quiet",
						onClick: () => setKind("dream"),
						children: "Мечта"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "goal-title",
					children: "Название"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "goal-title",
					value: title,
					onChange: (event) => setTitle(event.target.value),
					required: true
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "goal-desc",
					children: "Зачем это вам"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					id: "goal-desc",
					value: description,
					onChange: (event) => setDescription(event.target.value)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "goal-date",
					children: "К какой дате, если есть"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "goal-date",
					type: "date",
					value: targetDate,
					onChange: (event) => setTargetDate(event.target.value)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "goal-step",
					children: "Первый шаг"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "goal-step",
					value: firstStep,
					onChange: (event) => setFirstStep(event.target.value)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "goal-energy",
					children: "Когда лучше делать"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					id: "goal-energy",
					value: energy,
					onChange: (event) => setEnergy(event.target.value),
					children: Object.entries(ENERGY_LABEL).map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: id,
						children: label
					}, id))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Сохранить"
				})
			]
		})
	});
}
function AiGoal({ open, onClose, onSave }) {
	const plan = useServerFn(planGoal);
	const [description, setDescription] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [draft, setDraft] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		title: "Собрать шаги",
		onClose: () => {
			setError("");
			onClose();
		},
		children: !draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-3",
			onSubmit: async (event) => {
				event.preventDefault();
				setError("");
				if (description.trim().length < 8) {
					setError("Напишите чуть подробнее — пару предложений достаточно.");
					return;
				}
				setBusy(true);
				try {
					const result = await plan({ data: { description } });
					if (!result.ok) setError(result.error);
					else setDraft(result.plan);
				} catch {
					setError("Не вышло связаться с моделью. Запишите цель вручную.");
				} finally {
					setBusy(false);
				}
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Опишите цель или мечту. Модель предложит конкретные шаги и приоритеты — их можно поправить перед сохранением."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					value: description,
					onChange: (event) => setDescription(event.target.value),
					placeholder: "Хочу через полгода спокойно говорить на созвонах и не переводить каждое слово в голове",
					"aria-label": "Описание цели"
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-accent",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: busy,
					children: busy ? "Собираю шаги…" : "Собрать шаги"
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-3",
			onSubmit: (event) => {
				event.preventDefault();
				onSave(draft);
				setDraft(null);
				setDescription("");
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Поправьте, если чувствуете иначе. Потом шаги станут задачами."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					value: draft.title,
					onChange: (event) => setDraft({
						...draft,
						title: event.target.value
					}),
					"aria-label": "Название"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					value: draft.summary,
					onChange: (event) => setDraft({
						...draft,
						summary: event.target.value
					}),
					"aria-label": "Зачем"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: draft.kind === "goal" ? "primary" : "quiet",
						onClick: () => setDraft({
							...draft,
							kind: "goal"
						}),
						children: "Цель"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: draft.kind === "dream" ? "primary" : "quiet",
						onClick: () => setDraft({
							...draft,
							kind: "dream"
						}),
						children: "Мечта"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					type: "date",
					value: draft.targetDate ?? "",
					"aria-label": "Дата",
					onChange: (event) => setDraft({
						...draft,
						targetDate: event.target.value || void 0
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-3",
					children: draft.steps.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "grid gap-2 rounded-xl border border-line p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								value: step.title,
								"aria-label": `Шаг ${index + 1}`,
								onChange: (event) => {
									const steps = draft.steps.slice();
									steps[index] = {
										...step,
										title: event.target.value
									};
									setDraft({
										...draft,
										steps
									});
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
								value: step.priority,
								"aria-label": "Приоритет",
								onChange: (event) => {
									const steps = draft.steps.slice();
									steps[index] = {
										...step,
										priority: event.target.value
									};
									setDraft({
										...draft,
										steps
									});
								},
								children: PRIORITIES.map((priority) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: priority,
									children: PRIORITY_LABEL[priority]
								}, priority))
							}),
							step.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: step.note
							}) : null
						]
					}, index))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Сохранить цель"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						onClick: () => setDraft(null),
						children: "Описать заново"
					})]
				})
			]
		})
	});
}
var SplitComponent = function GoalsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoalsView, {}) });
};
//#endregion
export { SplitComponent as component };
