import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { O as todayKey, k as usePlanner, m as PageHead, p as PRIORITY_LABEL, r as Button, t as AppShell } from "./shell-mPTNwIV3.mjs";
import { a as endOfMonth, i as startOfMonth, o as startOfWeek, r as format, s as addDays, t as ru } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/print-CszdFngA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PrintView() {
	const tasks = usePlanner((state) => state.tasks);
	const goals = usePlanner((state) => state.goals);
	const [mode, setMode] = (0, import_react.useState)("week");
	const [anchor, setAnchor] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setAnchor(/* @__PURE__ */ new Date());
	}, []);
	const days = anchor ? range(mode, anchor) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "no-print",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
				kicker: "Для ручки",
				title: "Печать",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => window.print(),
					children: "Распечатать"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: chip(mode === "week"),
					onClick: () => setMode("week"),
					children: "Неделя"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: chip(mode === "month"),
					onClick: () => setMode("month"),
					children: "Месяц"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-5 text-sm text-muted",
				children: "Лист соберётся по задачам со сроком. Пустые строки можно дописать от руки и зачёркивать."
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "print-sheet rounded-2xl border border-line bg-surface p-6 text-ink shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-4xl",
				children: "Светлица"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: anchor ? mode === "week" ? `Неделя ${format(days[0] ?? anchor, "d MMMM", { locale: ru })} — ${format(days[days.length - 1] ?? anchor, "d MMMM", { locale: ru })}` : format(anchor, "LLLL yyyy", { locale: ru }) : "Список"
			}),
			goals.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 text-sm",
				children: goals.slice(0, 6).map((goal) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					goal.kind === "dream" ? "Мечта" : "Цель",
					": ",
					goal.title
				] }, goal.id))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-6",
				children: days.map((date) => {
					const key = todayKey(date);
					const items = tasks.filter((task) => task.due === key);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: format(date, "EEEE, d MMMM", { locale: ru }).replace(/^./, (letter) => letter.toUpperCase())
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-2",
						children: [items.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-3 border-b border-line py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Box, { done: task.done }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: task.done ? "line-through" : "",
								children: task.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: [PRIORITY_LABEL[task.priority], task.notes ? ` · ${task.notes}` : ""]
							})] })]
						}, task.id)), Array.from({ length: items.length > 0 ? 1 : 3 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3 border-b border-line py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Box, { done: false }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-4 flex-1 border-b border-line" })]
						}, `blank-${index}`))]
					})] }, key);
				})
			})
		]
	})] });
}
function Box({ done }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: done ? "mt-1 inline-block size-4 shrink-0 border border-ink bg-ink" : "mt-1 inline-block size-4 shrink-0 border border-ink" });
}
function chip(active) {
	return active ? "min-h-11 rounded-xl bg-accent-soft px-4 text-sm font-semibold" : "min-h-11 rounded-xl px-4 text-sm text-muted";
}
function range(mode, anchor) {
	if (mode === "week") {
		const start = startOfWeek(anchor, { weekStartsOn: 1 });
		return Array.from({ length: 7 }, (_, index) => addDays(start, index));
	}
	const start = startOfMonth(anchor);
	const end = endOfMonth(anchor);
	const days = [];
	for (let date = start; date <= end; date = addDays(date, 1)) days.push(date);
	return days;
}
var SplitComponent = function PrintPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintView, {}) });
};
//#endregion
export { SplitComponent as component };
