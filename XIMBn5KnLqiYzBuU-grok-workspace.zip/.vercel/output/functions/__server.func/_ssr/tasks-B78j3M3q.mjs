import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { A as useTodayKey, C as focusMinutes, D as priorityWeight, S as endOfWeekKey, _ as Select, a as ENERGY_LABEL, f as POINT_VALUES, g as REMIND_LABEL, h as PriorityMark, i as Card, k as usePlanner, l as Label, m as PageHead, n as Area, o as Empty, p as PRIORITY_LABEL, r as Button, s as Field, t as AppShell, u as Meter } from "./shell-mPTNwIV3.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tasks-B78j3M3q.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILTERS = [
	{
		id: "open",
		label: "Открытые"
	},
	{
		id: "today",
		label: "Сегодня"
	},
	{
		id: "week",
		label: "Неделя"
	},
	{
		id: "important",
		label: "Важные"
	},
	{
		id: "done",
		label: "Готовые"
	}
];
function TasksView() {
	const tasks = usePlanner((state) => state.tasks);
	const goals = usePlanner((state) => state.goals);
	const focusLog = usePlanner((state) => state.focusLog);
	const addTask = usePlanner((state) => state.addTask);
	const updateTask = usePlanner((state) => state.updateTask);
	const toggleTask = usePlanner((state) => state.toggleTask);
	const setProgress = usePlanner((state) => state.setProgress);
	const setAnchor = usePlanner((state) => state.setAnchor);
	const deleteTask = usePlanner((state) => state.deleteTask);
	const day = useTodayKey();
	const [filter, setFilter] = (0, import_react.useState)("open");
	const [goalId, setGoalId] = (0, import_react.useState)("all");
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const visible = (0, import_react.useMemo)(() => {
		const weekEnd = day ? endOfWeekKey(day) : "";
		return tasks.filter((task) => goalId === "all" ? true : task.goalId === goalId).filter((task) => {
			if (filter === "done") return task.done;
			if (task.done) return false;
			if (filter === "today") {
				if (!day) return false;
				return task.due === day || task.anchor || Boolean(task.due && task.due < day);
			}
			if (filter === "week") {
				if (!day || !task.due) return false;
				return task.due >= day && task.due <= weekEnd;
			}
			if (filter === "important") return task.priority === "critical" || task.priority === "high";
			return true;
		}).slice().sort((a, b) => {
			if (a.anchor !== b.anchor) return a.anchor ? -1 : 1;
			const ad = a.due ?? "9999-99-99";
			const bd = b.due ?? "9999-99-99";
			if (ad !== bd) return ad.localeCompare(bd);
			return priorityWeight(a.priority) - priorityWeight(b.priority);
		});
	}, [
		tasks,
		filter,
		goalId,
		day
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "Что сделать",
			title: "Задачи",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Важные можно двигать по проценту, пока не отметите готовыми."
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddTask, {
			goals: goals.map((goal) => ({
				id: goal.id,
				title: goal.title
			})),
			onAdd: addTask
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 flex flex-wrap gap-2",
			children: [FILTERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setFilter(item.id),
				className: filter === item.id ? "min-h-11 rounded-xl bg-accent-soft px-4 text-sm font-semibold" : "min-h-11 rounded-xl px-4 text-sm text-muted",
				children: item.label
			}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				className: "w-auto",
				value: goalId,
				"aria-label": "Фильтр по цели",
				onChange: (event) => setGoalId(event.target.value),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "all",
					children: "Все цели"
				}), goals.map((goal) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: goal.id,
					children: goal.title
				}, goal.id))]
			})]
		}),
		visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: "В этом срезе пусто",
				text: "Смените фильтр или добавьте задачу сверху. За закрытие придут очки."
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-5 grid gap-3",
			children: visible.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					className: "mt-1 size-5 accent-accent",
					checked: task.done,
					"aria-label": `Выполнено: ${task.title}`,
					onChange: () => {
						const delta = toggleTask(task.id);
						if (delta > 0) toast(`+${delta} очков`);
						if (delta < 0) toast("Отметку сняли");
					}
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-left",
							onClick: () => setOpenId(openId === task.id ? null : task.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: task.done ? "font-medium text-muted line-through" : "font-medium",
								children: task.title
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriorityMark, { priority: task.priority }),
								task.due ? ` · ${task.due}${task.dueTime ? ` ${task.dueTime}` : ""}` : "",
								task.energy !== "any" ? ` · ${ENERGY_LABEL[task.energy]}` : "",
								focusMinutes(focusLog, task.id) > 0 ? ` · ${focusMinutes(focusLog, task.id)} мин фокуса` : "",
								!task.done ? ` · ${POINT_VALUES[task.priority]} очков` : ""
							]
						}),
						!task.done && (task.priority === "critical" || task.priority === "high") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-3 block text-sm text-muted",
							children: [
								"Сделано ",
								task.progress,
								"%",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "range",
									min: 0,
									max: 100,
									value: task.progress,
									"aria-label": `Прогресс: ${task.title}`,
									className: "mt-1 w-full accent-accent",
									onChange: (event) => setProgress(task.id, Number(event.target.value))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
									value: task.progress,
									label: `Прогресс задачи ${task.title}`
								})
							]
						}) : null,
						openId === task.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskEditor, {
							task,
							goals: goals.map((goal) => ({
								id: goal.id,
								title: goal.title
							})),
							onChange: (patch) => updateTask(task.id, patch),
							onAnchor: () => setAnchor(task.id),
							onDelete: () => deleteTask(task.id)
						}) : null
					]
				})]
			}) }) }, task.id))
		})
	] });
}
function AddTask({ goals, onAdd }) {
	const [title, setTitle] = (0, import_react.useState)("");
	const [priority, setPriority] = (0, import_react.useState)("medium");
	const [due, setDue] = (0, import_react.useState)("");
	const [dueTime, setDueTime] = (0, import_react.useState)("");
	const [goalId, setGoalId] = (0, import_react.useState)("");
	const [remind, setRemind] = (0, import_react.useState)("morning");
	const [energy, setEnergy] = (0, import_react.useState)("any");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [more, setMore] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "grid gap-3",
		onSubmit: (event) => {
			event.preventDefault();
			if (!title.trim()) return;
			onAdd({
				title,
				priority,
				due,
				dueTime,
				goalId: goalId || void 0,
				remind,
				energy,
				notes
			});
			setTitle("");
			setNotes("");
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor: "task-title",
				children: "Новая задача"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "task-title",
					value: title,
					onChange: (event) => setTitle(event.target.value),
					placeholder: "Что нужно сделать"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Добавить"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					value: priority,
					"aria-label": "Важность",
					onChange: (event) => setPriority(event.target.value),
					children: Object.keys(PRIORITY_LABEL).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: id,
						children: PRIORITY_LABEL[id]
					}, id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					type: "date",
					value: due,
					"aria-label": "Срок",
					onChange: (event) => setDue(event.target.value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "min-h-11 text-left text-sm font-semibold text-accent",
				onClick: () => setMore((value) => !value),
				children: more ? "Скрыть подробности" : "Срок, напоминание, цель"
			}),
			more ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "task-time",
						children: "Время срока"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						id: "task-time",
						type: "time",
						value: dueTime,
						onChange: (event) => setDueTime(event.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "task-remind",
						children: "Напоминание"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						id: "task-remind",
						value: remind,
						onChange: (event) => setRemind(event.target.value),
						children: Object.keys(REMIND_LABEL).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: id,
							children: REMIND_LABEL[id]
						}, id))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "task-energy",
						children: "Когда по силам"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						id: "task-energy",
						value: energy,
						onChange: (event) => setEnergy(event.target.value),
						children: Object.keys(ENERGY_LABEL).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: id,
							children: ENERGY_LABEL[id]
						}, id))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "task-goal",
						children: "Цель"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						id: "task-goal",
						value: goalId,
						onChange: (event) => setGoalId(event.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Без цели"
						}), goals.map((goal) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: goal.id,
							children: goal.title
						}, goal.id))]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "task-notes",
							children: "Заметка"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
							id: "task-notes",
							value: notes,
							onChange: (event) => setNotes(event.target.value)
						})]
					})
				]
			}) : null
		]
	}) });
}
function TaskEditor({ task, goals, onChange, onAnchor, onDelete }) {
	const [sure, setSure] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 grid gap-3 border-t border-line pt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				value: task.title,
				"aria-label": "Название",
				onChange: (event) => onChange({ title: event.target.value })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
				value: task.notes,
				"aria-label": "Заметка",
				onChange: (event) => onChange({ notes: event.target.value })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						value: task.priority,
						"aria-label": "Важность",
						onChange: (event) => onChange({ priority: event.target.value }),
						children: Object.keys(PRIORITY_LABEL).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: id,
							children: PRIORITY_LABEL[id]
						}, id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						value: task.remind,
						"aria-label": "Напоминание",
						onChange: (event) => onChange({ remind: event.target.value }),
						children: Object.keys(REMIND_LABEL).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: id,
							children: REMIND_LABEL[id]
						}, id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						type: "date",
						value: task.due ?? "",
						"aria-label": "Дата",
						onChange: (event) => onChange({ due: event.target.value || void 0 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						type: "time",
						value: task.dueTime ?? "",
						"aria-label": "Время",
						onChange: (event) => onChange({ dueTime: event.target.value || void 0 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						value: task.energy,
						"aria-label": "Время дня",
						onChange: (event) => onChange({ energy: event.target.value }),
						children: Object.keys(ENERGY_LABEL).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: id,
							children: ENERGY_LABEL[id]
						}, id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: task.goalId ?? "",
						"aria-label": "Цель",
						onChange: (event) => onChange({ goalId: event.target.value || void 0 }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Без цели"
						}), goals.map((goal) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: goal.id,
							children: goal.title
						}, goal.id))]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "quiet",
					onClick: onAnchor,
					children: task.anchor ? "Убрать с главного" : "Сделать главной на сегодня"
				}), sure ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "danger",
					onClick: () => {
						onDelete();
						toast("Задача удалена");
					},
					children: "Точно удалить"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "danger",
					onClick: () => setSure(true),
					children: "Удалить"
				})]
			})
		]
	});
}
var SplitComponent = function TasksPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TasksView, {}) });
};
//#endregion
export { SplitComponent as component };
