import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as ChevronRight, f as ChevronLeft } from "../_libs/lucide-react.mjs";
import { A as useTodayKey, O as todayKey, c as IconButton, h as PriorityMark, i as Card, k as usePlanner, m as PageHead, t as AppShell, v as buildMonth, y as cn } from "./shell-mPTNwIV3.mjs";
import { r as format, t as ru } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/calendar-BS46aoM7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var WEEKDAYS = [
	"пн",
	"вт",
	"ср",
	"чт",
	"пт",
	"сб",
	"вс"
];
function CalendarView() {
	const day = useTodayKey();
	const tasks = usePlanner((state) => state.tasks);
	const scheduled = usePlanner((state) => state.scheduled);
	const toggleTask = usePlanner((state) => state.toggleTask);
	const [cursor, setCursor] = (0, import_react.useState)(null);
	const [selected, setSelected] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setCursor((current) => current ?? /* @__PURE__ */ new Date());
	}, []);
	const year = cursor?.getFullYear() ?? 0;
	const month = cursor?.getMonth() ?? 0;
	const cells = buildMonth(year, month);
	const active = selected ?? day;
	const title = format(new Date(year, month, 1), "LLLL yyyy", { locale: ru }).replace(/^./, (letter) => letter.toUpperCase());
	const dayTasks = tasks.filter((task) => task.due === active);
	const dayFocus = scheduled.filter((item) => todayKey(new Date(item.start)) === active);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
		kicker: "Сроки и сессии",
		title: "Календарь"
	}), !cursor ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Собираю месяц."
	}) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-center justify-between gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
					label: "Предыдущий месяц",
					onClick: () => setCursor(new Date(year, month - 1, 1)),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
					label: "Следующий месяц",
					onClick: () => setCursor(new Date(year, month + 1, 1)),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-7 gap-1 text-center text-sm text-muted",
			children: WEEKDAYS.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "py-2",
				children: name
			}, name))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-7 gap-1",
			children: cells.map((cell, index) => {
				if (!cell) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {}, `empty-${index}`);
				const count = tasks.filter((task) => task.due === cell && !task.done).length;
				const focus = scheduled.some((item) => !item.done && todayKey(new Date(item.start)) === cell);
				const number = Number(cell.slice(-2));
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setSelected(cell),
					className: cn("flex min-h-14 flex-col items-center justify-center rounded-xl text-sm", cell === active ? "bg-accent text-on-accent" : "hover:bg-surface-2", cell === day && cell !== active && "border border-accent"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: number
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 flex gap-1",
						"aria-hidden": true,
						children: [count > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-1.5 rounded-full", cell === active ? "bg-on-accent" : "bg-accent") }) : null, focus ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-1.5 rounded-full", cell === active ? "bg-on-accent" : "bg-ink") }) : null]
					})]
				}, cell);
			})
		})
	] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "mt-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-3xl",
			children: active ? format(parse(active), "EEEE, d MMMM", { locale: ru }).replace(/^./, (letter) => letter.toUpperCase()) : "День"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "mt-3 divide-y divide-line",
			children: [
				dayTasks.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-start gap-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						className: "mt-1 size-5 accent-accent",
						checked: task.done,
						"aria-label": `Выполнено: ${task.title}`,
						onChange: () => toggleTask(task.id)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: task.done ? "text-muted line-through" : "",
						children: task.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriorityMark, { priority: task.priority })] })]
				}, task.id)),
				dayFocus.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "py-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: item.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-muted",
						children: [
							"Фокус · ",
							format(new Date(item.start), "HH:mm"),
							" · ",
							item.minutes,
							" мин",
							item.done ? " · прошло" : ""
						]
					})]
				}, item.id)),
				dayTasks.length === 0 && dayFocus.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "py-3 text-muted",
					children: "В этот день пусто."
				}) : null
			]
		})]
	})] })] });
}
function parse(day) {
	const [y, m, d] = day.split("-").map(Number);
	return new Date(y, (m || 1) - 1, d || 1);
}
var SplitComponent = function CalendarPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarView, {}) });
};
//#endregion
export { SplitComponent as component };
