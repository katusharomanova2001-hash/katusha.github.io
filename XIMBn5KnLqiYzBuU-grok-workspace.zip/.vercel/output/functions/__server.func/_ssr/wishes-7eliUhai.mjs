import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as Card, k as usePlanner, l as Label, m as PageHead, n as Area, o as Empty, r as Button, s as Field, t as AppShell } from "./shell-mPTNwIV3.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/wishes-7eliUhai.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function WishesView() {
	const wishes = usePlanner((state) => state.wishes);
	const addWish = usePlanner((state) => state.addWish);
	const updateWish = usePlanner((state) => state.updateWish);
	const deleteWish = usePlanner((state) => state.deleteWish);
	const [show, setShow] = (0, import_react.useState)("open");
	const [title, setTitle] = (0, import_react.useState)("");
	const [url, setUrl] = (0, import_react.useState)("");
	const [price, setPrice] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [image, setImage] = (0, import_react.useState)();
	const visible = wishes.filter((wish) => show === "bought" ? wish.bought : !wish.bought);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "Не срочно, но хочется",
			title: "Желания"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-3",
			onSubmit: (event) => {
				event.preventDefault();
				if (!title.trim()) return;
				addWish({
					title,
					url,
					price,
					note,
					image
				});
				setTitle("");
				setUrl("");
				setPrice("");
				setNote("");
				setImage(void 0);
				toast("Добавлено в список");
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "wish-title",
					children: "Что хочется"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					id: "wish-title",
					value: title,
					onChange: (event) => setTitle(event.target.value)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "wish-url",
						children: "Ссылка"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						id: "wish-url",
						type: "url",
						placeholder: "https://",
						value: url,
						onChange: (event) => setUrl(event.target.value)
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "wish-price",
						children: "Цена, как вам удобно"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						id: "wish-price",
						value: price,
						onChange: (event) => setPrice(event.target.value),
						placeholder: "4 200 ₽"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "wish-note",
					children: "Заметка"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					id: "wish-note",
					value: note,
					onChange: (event) => setNote(event.target.value)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "wish-photo",
						children: "Фото"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						id: "wish-photo",
						type: "file",
						accept: "image/*",
						onChange: async (event) => {
							const file = event.target.files?.[0];
							event.target.value = "";
							if (!file) return;
							try {
								const data = await compressImage(file);
								if (data.length > 18e4) {
									toast("Фото слишком большое. Возьмите другое или поменьше.");
									return;
								}
								setImage(data);
							} catch {
								toast("Не удалось прочитать фото");
							}
						}
					}),
					image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: image,
						alt: "",
						className: "mt-3 h-36 w-full rounded-xl object-cover"
					}) : null
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Добавить"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Фото остаётся в этом браузере вместе с остальными записями."
				})
			]
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: chip(show === "open"),
				onClick: () => setShow("open"),
				children: "Хочу"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: chip(show === "bought"),
				onClick: () => setShow("bought"),
				children: "Уже есть"
			})]
		}),
		visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: "Список пуст",
				text: "Сюда можно складывать вещи, курсы и поездки: название, ссылку и фото."
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-5 grid gap-4 sm:grid-cols-2",
			children: visible.map((wish) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex h-full flex-col",
				children: [
					wish.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: wish.image,
						alt: "",
						className: "mb-4 h-44 w-full rounded-xl object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-4 flex h-44 items-center justify-center rounded-xl bg-accent-soft",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-5xl text-accent",
							children: wish.title.slice(0, 1)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: wish.bought ? "font-display text-3xl text-muted line-through" : "font-display text-3xl",
						children: wish.title
					}),
					wish.price ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: wish.price
					}) : null,
					wish.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm",
						children: wish.note
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [
							wish.url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: wish.url,
								target: "_blank",
								rel: "noreferrer",
								className: "inline-flex min-h-11 items-center text-sm font-semibold text-accent",
								children: "Открыть ссылку"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "quiet",
								onClick: () => updateWish(wish.id, { bought: !wish.bought }),
								children: wish.bought ? "Снова хочу" : "Уже куплено"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "danger",
								onClick: () => deleteWish(wish.id),
								children: "Удалить"
							})
						]
					})
				]
			}) }, wish.id))
		})
	] });
}
function chip(active) {
	return active ? "min-h-11 rounded-xl bg-accent-soft px-4 text-sm font-semibold" : "min-h-11 rounded-xl px-4 text-sm text-muted";
}
function compressImage(file) {
	return new Promise((resolve, reject) => {
		const url = URL.createObjectURL(file);
		const image = new Image();
		image.onload = () => {
			const scale = Math.min(1, 960 / Math.max(image.width, image.height));
			const canvas = document.createElement("canvas");
			canvas.width = Math.max(1, Math.round(image.width * scale));
			canvas.height = Math.max(1, Math.round(image.height * scale));
			const context = canvas.getContext("2d");
			if (!context) {
				URL.revokeObjectURL(url);
				reject(/* @__PURE__ */ new Error("canvas"));
				return;
			}
			context.drawImage(image, 0, 0, canvas.width, canvas.height);
			const data = canvas.toDataURL("image/jpeg", .72);
			URL.revokeObjectURL(url);
			resolve(data);
		};
		image.onerror = () => {
			URL.revokeObjectURL(url);
			reject(/* @__PURE__ */ new Error("image"));
		};
		image.src = url;
	});
}
var SplitComponent = function WishesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WishesView, {}) });
};
//#endregion
export { SplitComponent as component };
