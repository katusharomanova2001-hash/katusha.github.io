import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { A as useTodayKey, E as pickQuote, T as greet, a as ENERGY_LABEL, b as completionStreak, h as PriorityMark, i as Card, j as weekKey, k as usePlanner, r as Button, s as Field, t as AppShell, u as Meter } from "./shell-mPTNwIV3.mjs";
import { r as format, t as ru } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BhOhhhqM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TodayView() {
	const day = useTodayKey();
	const settings = usePlanner((state) => state.settings);
	const setSettings = usePlanner((state) => state.setSettings);
	const quotes = usePlanner((state) => state.quotes);
	const points = usePlanner((state) => state.points);
	const tasks = usePlanner((state) => state.tasks);
	const water = usePlanner((state) => state.water);
	const addWater = usePlanner((state) => state.addWater);
	const toggleTask = usePlanner((state) => state.toggleTask);
	const addTask = usePlanner((state) => state.addTask);
	const scheduled = usePlanner((state) => state.scheduled);
	const events = usePlanner((state) => state.events);
	const weekNotes = usePlanner((state) => state.weekNotes);
	const setWeekNote = usePlanner((state) => state.setWeekNote);
	const [hello, setHello] = (0, import_react.useState)("Здравствуйте");
	const [dateLabel, setDateLabel] = (0, import_react.useState)("Сегодня");
	const [draft, setDraft] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const now = /* @__PURE__ */ new Date();
		setHello(greet(now));
		setDateLabel(format(now, "EEEE, d MMMM", { locale: ru }).replace(/^./, (letter) => letter.toUpperCase()));
	}, [day]);
	const quote = pickQuote(quotes, settings.activeQuoteId);
	const name = settings.name.trim();
	const glasses = day ? water[day] ?? 0 : 0;
	const open = tasks.filter((task) => !task.done);
	const anchor = open.find((task) => task.anchor);
	const overdue = day ? open.filter((task) => task.due && task.due < day && !task.anchor) : [];
	const todayTasks = day ? open.filter((task) => task.due === day && !task.anchor) : [];
	const streak = day ? completionStreak(events, day) : 0;
	const noteKey = day ? weekKey(/* @__PURE__ */ new Date()) : "";
	const note = weekNotes[noteKey];
	const upcoming = scheduled.filter((item) => !item.done).slice().sort((a, b) => a.start.localeCompare(b.start))[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: dateLabel
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-5xl leading-tight text-ink md:text-6xl",
					children: name ? `${hello}, ${name}` : hello
				}),
				streak >= 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: [
						"Уже ",
						streak,
						" дн. подряд закрываете хотя бы одно."
					]
				}) : null
			] }),
			!name ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: "hello-name",
				className: "text-sm text-muted",
				children: "Как к вам обращаться?"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				id: "hello-name",
				className: "mt-2",
				maxLength: 40,
				placeholder: "Имя",
				value: settings.name,
				onChange: (event) => setSettings({ name: event.target.value })
			})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "lg:col-span-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
							className: "font-display text-3xl italic leading-snug text-ink md:text-4xl",
							children: quote.text
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-muted",
							children: quote.author
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex flex-wrap items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "tabular-nums text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold",
										children: points
									}),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted",
										children: "очков"
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/quotes",
								className: "min-h-11 inline-flex items-center text-sm font-semibold text-accent",
								children: "Витрина цитат"
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "lg:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-3xl",
								children: "Вода"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "tabular-nums text-sm text-muted",
								children: [
									glasses,
									" / ",
									settings.waterGoal
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 flex flex-wrap gap-2",
							children: Array.from({ length: settings.waterGoal }, (_, index) => {
								const filled = index < glasses;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": filled ? `Убрать стакан ${index + 1}` : `Отметить стакан ${index + 1}`,
									disabled: !day,
									onClick: () => {
										if (!day) return;
										const next = filled ? index : index + 1;
										addWater(day, next - glasses);
									},
									className: filled ? "size-11 rounded-full bg-accent" : "size-11 rounded-full border border-line bg-surface-2"
								}, index);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: "Пустой кружок доливает до него. Полный откатывает."
						})
					]
				})]
			}),
			anchor ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Главное на сегодня"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						className: "mt-2 size-5 accent-accent",
						checked: false,
						"aria-label": `Выполнено: ${anchor.title}`,
						onChange: () => reward(toggleTask(anchor.id))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-3xl leading-tight",
								children: anchor.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriorityMark, { priority: anchor.priority }),
									anchor.energy !== "any" ? ` · ${ENERGY_LABEL[anchor.energy]}` : "",
									anchor.progress > 0 ? ` · ${anchor.progress}%` : ""
								]
							}),
							anchor.priority === "critical" || anchor.priority === "high" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
									value: anchor.progress,
									label: "Прогресс главной задачи"
								})
							}) : null
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/focus",
					className: "mt-4 inline-flex min-h-11 items-center text-sm font-semibold text-accent",
					children: "25 минут на это"
				})
			] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl",
					children: "На сегодня"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-4 flex flex-col gap-2 sm:flex-row",
					onSubmit: (event) => {
						event.preventDefault();
						if (!draft.trim() || !day) return;
						addTask({
							title: draft,
							due: day,
							priority: "high",
							remind: "morning"
						});
						setDraft("");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						value: draft,
						onChange: (event) => setDraft(event.target.value),
						placeholder: "Быстро добавить задачу на сегодня",
						"aria-label": "Новая задача на сегодня"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Добавить"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskGroup, {
					title: "Просрочено",
					tasks: overdue,
					onToggle: (id) => reward(toggleTask(id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskGroup, {
					title: anchor ? "Ещё сегодня" : "Сегодня",
					tasks: todayTasks,
					onToggle: (id) => reward(toggleTask(id))
				}),
				!anchor && overdue.length === 0 && todayTasks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-muted",
					children: [
						"Пока пусто. Добавьте одну задачу сюда или",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/goals",
							className: "font-semibold text-accent",
							children: "соберите цель"
						}),
						"."
					]
				}) : null
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: "Ближайший фокус"
					}),
					upcoming ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold",
							children: upcoming.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-1 block text-sm text-muted",
							children: [
								format(new Date(upcoming.start), "d MMMM, HH:mm", { locale: ru }),
								" · ",
								upcoming.minutes,
								" мин"
							]
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-muted",
						children: "Сессий впереди нет."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/focus",
						className: "mt-4 inline-flex min-h-11 items-center text-sm font-semibold text-accent",
						children: "Открыть фокус"
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: "Итог недели"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Три короткие строки, чтобы неделя не рассыпалась."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeekField, {
						label: "Что сдвинулось",
						value: note?.moved ?? "",
						onBlur: (value) => noteKey && setWeekNote(noteKey, { moved: value })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeekField, {
						label: "Что отпустить",
						value: note?.drop ?? "",
						onBlur: (value) => noteKey && setWeekNote(noteKey, { drop: value })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeekField, {
						label: "Чему отдать утро",
						value: note?.focus ?? "",
						onBlur: (value) => noteKey && setWeekNote(noteKey, { focus: value })
					})
				] })]
			})
		]
	});
}
function reward(delta) {
	if (delta > 0) toast(`+${delta} очков`);
	if (delta < 0) toast("Отметку сняли, очки вернулись");
}
function TaskGroup({ title, tasks, onToggle }) {
	if (!tasks.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-2 divide-y divide-line",
			children: tasks.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-start gap-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					className: "mt-1 size-5 accent-accent",
					checked: false,
					"aria-label": `Выполнено: ${task.title}`,
					onChange: () => onToggle(task.id)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: task.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriorityMark, { priority: task.priority })]
				})]
			}, task.id))
		})]
	});
}
function WeekField({ label, value, onBlur }) {
	const [text, setText] = (0, import_react.useState)(value);
	(0, import_react.useEffect)(() => setText(value), [value]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "mt-3 block text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			className: "mt-1",
			value: text,
			maxLength: 160,
			onChange: (event) => setText(event.target.value),
			onBlur: () => onBlur(text)
		})]
	});
}
var SplitComponent = function HomePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TodayView, {}) });
};
//#endregion
export { SplitComponent as component };
