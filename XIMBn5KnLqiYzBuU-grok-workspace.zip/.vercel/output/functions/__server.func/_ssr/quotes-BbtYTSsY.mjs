import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as Card, k as usePlanner, m as PageHead, r as Button, t as AppShell, y as cn } from "./shell-mPTNwIV3.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quotes-BbtYTSsY.js
var import_jsx_runtime = require_jsx_runtime();
function QuotesView() {
	const quotes = usePlanner((state) => state.quotes);
	const points = usePlanner((state) => state.points);
	const active = usePlanner((state) => state.settings.activeQuoteId);
	const unlockQuote = usePlanner((state) => state.unlockQuote);
	const setActiveQuote = usePlanner((state) => state.setActiveQuote);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "Очки с закрытых задач",
			title: "Цитаты",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "tabular-nums text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold",
						children: points
					}),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: "очков"
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-5 max-w-2xl text-muted",
			children: "Три фразы уже открыты. Остальные покупаются очками: срочная задача даёт 30, важная — 18, обычная — 10."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid gap-4",
			children: quotes.map((quote) => {
				const current = quote.id === active && quote.unlocked;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: cn(current && "border-accent"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
						className: "font-display text-2xl italic leading-snug",
						children: quote.text
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap items-center gap-2",
						children: [
							quote.cost === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: "Уже ваша"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums text-sm",
								children: [quote.cost, " очков"]
							}),
							current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-semibold text-accent",
								children: "На главном экране"
							}) : null,
							quote.unlocked && !current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "quiet",
								onClick: () => setActiveQuote(quote.id),
								children: "На главный экран"
							}) : null,
							!quote.unlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => {
									const result = unlockQuote(quote.id);
									if (result === "ok") toast("Цитата открыта и стоит на главном");
									if (result === "poor") toast("Пока не хватает очков");
								},
								children: "Открыть"
							}) : null
						]
					})]
				}) }, quote.id);
			})
		})
	] });
}
var SplitComponent = function QuotesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuotesView, {}) });
};
//#endregion
export { SplitComponent as component };
