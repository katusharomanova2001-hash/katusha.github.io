import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { A as useTodayKey, _ as Select, i as Card, j as weekKey, k as usePlanner, l as Label, m as PageHead, r as Button, s as Field, t as AppShell, x as elapsedMs } from "./shell-mPTNwIV3.mjs";
import { r as format, t as ru } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/focus-BKCvm4D2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FocusView() {
	const tasks = usePlanner((state) => state.tasks);
	const active = usePlanner((state) => state.active);
	const focusLog = usePlanner((state) => state.focusLog);
	const scheduled = usePlanner((state) => state.scheduled);
	const startFocus = usePlanner((state) => state.startFocus);
	const pauseFocus = usePlanner((state) => state.pauseFocus);
	const resumeFocus = usePlanner((state) => state.resumeFocus);
	const finishFocus = usePlanner((state) => state.finishFocus);
	const discardFocus = usePlanner((state) => state.discardFocus);
	const scheduleFocus = usePlanner((state) => state.scheduleFocus);
	const deleteScheduled = usePlanner((state) => state.deleteScheduled);
	const day = useTodayKey();
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	const [minutes, setMinutes] = (0, import_react.useState)(25);
	const [taskId, setTaskId] = (0, import_react.useState)("");
	const [title, setTitle] = (0, import_react.useState)("");
	const [when, setWhen] = (0, import_react.useState)("");
	const [planMinutes, setPlanMinutes] = (0, import_react.useState)(25);
	const [remind, setRemind] = (0, import_react.useState)(10);
	(0, import_react.useEffect)(() => {
		if (!active?.running) return;
		const id = window.setInterval(() => setNow(Date.now()), 250);
		return () => window.clearInterval(id);
	}, [active?.running]);
	(0, import_react.useEffect)(() => {
		if (!active?.running) return;
		const left = active.plannedMinutes * 6e4 - elapsedMs(active);
		const id = window.setTimeout(() => {
			const logged = usePlanner.getState().finishFocus();
			if (logged > 0) toast(`Сессия записана: ${logged} мин`);
		}, Math.max(0, left));
		return () => window.clearTimeout(id);
	}, [
		active?.running,
		active?.startedAt,
		active?.accumulatedMs,
		active?.plannedMinutes
	]);
	const spent = active ? elapsedMs(active, now) : 0;
	const total = (active?.plannedMinutes ?? minutes) * 6e4;
	const left = Math.max(0, total - spent);
	const ratio = total === 0 ? 0 : Math.min(1, spent / total);
	const radius = 52;
	const circ = 2 * Math.PI * radius;
	const clock = formatClock(left);
	const weekStart = day ? weekKey(/* @__PURE__ */ new Date()) : "";
	const weekLog = focusLog.filter((entry) => !weekStart || entry.day >= weekStart);
	const weekMinutes = weekLog.reduce((sum, entry) => sum + entry.minutes, 0);
	const openTasks = tasks.filter((task) => !task.done);
	const anchor = openTasks.find((task) => task.anchor);
	(0, import_react.useEffect)(() => {
		if (anchor && !taskId) setTaskId(anchor.id);
	}, [anchor, taskId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "Сколько вы были здесь",
			title: "Фокус"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-5 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex flex-col items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative grid place-items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						viewBox: "0 0 120 120",
						className: "size-56 -rotate-90",
						"aria-hidden": true,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "60",
							cy: "60",
							r: radius,
							fill: "none",
							strokeWidth: "8",
							className: "stroke-line"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "60",
							cy: "60",
							r: radius,
							fill: "none",
							strokeWidth: "8",
							strokeLinecap: "round",
							className: "stroke-accent",
							strokeDasharray: circ,
							strokeDashoffset: circ * (1 - ratio)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-5xl tabular-nums text-ink",
							children: clock
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 max-w-40 text-sm text-muted",
							children: active?.title ?? "Готово к старту"
						})]
					})]
				}), !active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid w-full gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								15,
								25,
								45
							].map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: minutes === value ? "primary" : "quiet",
								onClick: () => setMinutes(value),
								children: [value, " мин"]
							}, value))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "focus-task",
							children: "Задача"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							id: "focus-task",
							value: taskId,
							onChange: (event) => setTaskId(event.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Без привязки"
							}), openTasks.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: task.id,
								children: task.title
							}, task.id))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								const task = openTasks.find((item) => item.id === taskId);
								if (!startFocus({
									title: task?.title || "Свободный фокус",
									taskId: task?.id,
									plannedMinutes: minutes
								})) toast("Сначала завершите текущую сессию");
							},
							children: "Начать"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [
						active.running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							onClick: pauseFocus,
							children: "Пауза"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							onClick: resumeFocus,
							children: "Дальше"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								const logged = finishFocus();
								toast(logged > 0 ? `Записано ${logged} мин` : "Слишком коротко, в отчёт не попало");
							},
							children: "Завершить"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: discardFocus,
							children: "Сбросить"
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: "Эта неделя"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-5xl tabular-nums",
						children: weekMinutes
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "минут в фокусе"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-4 divide-y divide-line",
						children: [weekLog.slice(0, 6).map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-baseline justify-between gap-3 py-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 truncate",
								children: entry.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums text-muted",
								children: [entry.minutes, " мин"]
							})]
						}, entry.id)), weekLog.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "py-2 text-sm text-muted",
							children: "Сессий ещё не было."
						}) : null]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl",
					children: "Запланировать"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-4 grid gap-3",
					onSubmit: (event) => {
						event.preventDefault();
						const task = openTasks.find((item) => item.id === taskId);
						scheduleFocus({
							title: title.trim() || task?.title || "Фокус",
							taskId: task?.id,
							start: new Date(when).toISOString(),
							minutes: planMinutes,
							remindMinutes: remind
						});
						setTitle("");
						setWhen("");
						toast("Сессия в календаре. Напомню, пока страница открыта.");
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							value: title,
							onChange: (event) => setTitle(event.target.value),
							placeholder: "Название, если не из задачи",
							"aria-label": "Название сессии"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							type: "datetime-local",
							required: true,
							value: when,
							"aria-label": "Когда",
							onChange: (event) => setWhen(event.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								type: "number",
								min: 5,
								max: 180,
								value: planMinutes,
								"aria-label": "Длительность",
								onChange: (event) => setPlanMinutes(Number(event.target.value))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: String(remind),
								"aria-label": "Напомнить за",
								onChange: (event) => setRemind(Number(event.target.value)),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "0",
										children: "В момент старта"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "5",
										children: "За 5 минут"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "10",
										children: "За 10 минут"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "15",
										children: "За 15 минут"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "30",
										children: "За 30 минут"
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: "Поставить в календарь"
						})
					]
				})] })]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-5 grid gap-3",
			children: scheduled.filter((item) => !item.done).slice().sort((a, b) => a.start.localeCompare(b.start)).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: item.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						format(new Date(item.start), "d MMMM, HH:mm", { locale: ru }),
						" · ",
						item.minutes,
						" мин · напоминание за",
						" ",
						item.remindMinutes,
						" мин"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "quiet",
						onClick: () => {
							if (!startFocus({
								title: item.title,
								taskId: item.taskId,
								plannedMinutes: item.minutes,
								scheduleId: item.id
							})) toast("Сначала завершите текущую сессию");
						},
						children: "Начать сейчас"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: () => deleteScheduled(item.id),
						children: "Убрать"
					})]
				})]
			}) }, item.id))
		})
	] });
}
function formatClock(ms) {
	const total = Math.max(0, Math.ceil(ms / 1e3));
	const m = Math.floor(total / 60);
	const s = total % 60;
	return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
var SplitComponent = function FocusPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FocusView, {}) });
};
//#endregion
export { SplitComponent as component };
