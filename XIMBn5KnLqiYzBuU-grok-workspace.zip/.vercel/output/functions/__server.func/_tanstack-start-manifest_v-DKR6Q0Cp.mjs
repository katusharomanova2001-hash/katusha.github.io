//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DKR6Q0Cp.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/calendar",
			"/focus",
			"/goals",
			"/insights",
			"/print",
			"/quotes",
			"/tasks",
			"/wishes"
		],
		preloads: ["/assets/index-CRdZjjVf.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CRdZjjVf.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Bi6VUGi3.js",
			"/assets/shell-Bz3Cc6MU.js",
			"/assets/ru-BNBIT7K7.js"
		]
	},
	"/calendar": {
		filePath: "/workspace/src/routes/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-_c5uFp86.js",
			"/assets/shell-Bz3Cc6MU.js",
			"/assets/ru-BNBIT7K7.js"
		]
	},
	"/focus": {
		filePath: "/workspace/src/routes/focus.tsx",
		children: void 0,
		preloads: [
			"/assets/focus-BL89xeT5.js",
			"/assets/shell-Bz3Cc6MU.js",
			"/assets/ru-BNBIT7K7.js"
		]
	},
	"/goals": {
		filePath: "/workspace/src/routes/goals.tsx",
		children: void 0,
		preloads: ["/assets/goals-BeikbXWK.js", "/assets/shell-Bz3Cc6MU.js"]
	},
	"/insights": {
		filePath: "/workspace/src/routes/insights.tsx",
		children: void 0,
		preloads: [
			"/assets/insights-D2FxdZhb.js",
			"/assets/shell-Bz3Cc6MU.js",
			"/assets/ru-BNBIT7K7.js"
		]
	},
	"/print": {
		filePath: "/workspace/src/routes/print.tsx",
		children: void 0,
		preloads: [
			"/assets/print-C8cLyjfZ.js",
			"/assets/shell-Bz3Cc6MU.js",
			"/assets/ru-BNBIT7K7.js"
		]
	},
	"/quotes": {
		filePath: "/workspace/src/routes/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-4EuoQBFO.js", "/assets/shell-Bz3Cc6MU.js"]
	},
	"/tasks": {
		filePath: "/workspace/src/routes/tasks.tsx",
		children: void 0,
		preloads: ["/assets/tasks-B9wSIU2V.js", "/assets/shell-Bz3Cc6MU.js"]
	},
	"/wishes": {
		filePath: "/workspace/src/routes/wishes.tsx",
		children: void 0,
		preloads: ["/assets/wishes-CkSim4MH.js", "/assets/shell-Bz3Cc6MU.js"]
	}
} });
//#endregion
export { tsrStartManifest };
